// session-manager.js
// One Session = one ongoing Claude Agent SDK conversation.
// The session owns:
//   - a streaming-input async iterator we can push user messages into
//   - a queue of structured events to forward upstream
//   - a permission-pending registry (requestId → resolver) for canUseTool round-trips
//
// emit(event) — caller-supplied function for forwarding events to the server.
//
// Events have shape: { sessionId, type, ...fields }
// Inbound commands handled by Session: input, permissionResponse, interrupt, close.

const path = require('node:path')
const fs = require('node:fs')
const { query } = require('@anthropic-ai/claude-agent-sdk')
const { saveConfig } = require('./config')

const PERMISSION_TIMEOUT_MS = 5 * 60 * 1000

// Resolve the bundled Claude Code native binary at agent startup so we can
// pass it explicitly to query() and surface useful errors if it's missing.
function resolveBundledClaudeExe() {
  const platform = process.platform
  const arch = process.arch
  const ext = platform === 'win32' ? '.exe' : ''
  const pkg = `@anthropic-ai/claude-agent-sdk-${platform}-${arch}`
  try {
    // The native package only ships claude.exe + package.json — its package.json
    // has no main, so resolve via require.resolve on package.json.
    const pkgPath = require.resolve(`${pkg}/package.json`)
    const dir = path.dirname(pkgPath)
    const exe = path.join(dir, `claude${ext}`)
    return { exe, exists: fs.existsSync(exe), pkg, dir }
  } catch (err) {
    return { exe: null, exists: false, pkg, error: err.message }
  }
}

const claudeExeInfo = resolveBundledClaudeExe()
console.log(`[session-manager] claudeExe ${claudeExeInfo.exe || '(unresolved)'} exists=${claudeExeInfo.exists}` +
  (claudeExeInfo.error ? ` error=${claudeExeInfo.error}` : ''))

class Session {
  constructor({ id, name, folder, model, resume, emit, log, manager, verbose }) {
    this.id = id
    this.name = name || (folder ? path.basename(folder) : 'Untitled')
    this.folder = folder || null
    this.model = model || null
    this.resume = resume || null  // SDK session_id of a past JSONL transcript to continue
    this.emit = emit
    this.log = log || (() => {})
    this.manager = manager  // SessionManager — exposes shared permission state
    this.verbose = !!verbose  // Dump every SDK message to stdout when true

    // Tools the user allowed for the duration of THIS session.
    this._sessionAllowedTools = new Set()

    // Streaming-text accumulators, keyed by content block index. The SDK
    // can deliver assistant text either as one complete message or, when
    // includePartialMessages is enabled, as a sequence of text_delta events.
    // We keep the running text per block so the browser can render it
    // smoothly without having to know about deltas.
    this._streamingText = new Map()
    // Set of streamIds we've finished streaming, so the duplicate full
    // 'assistant' message that follows can be suppressed.
    this._streamedBlocks = new Set()
    // The current message_id from message_start; used to build streamIds.
    this._currentMessageId = null

    this.startedAt = Date.now()
    this.closed = false
    this.aborted = false

    // Streaming input plumbing
    this._pendingInputs = []
    this._inputResolver = null

    // Pending permission requests: requestId → { resolve, reject, timer }
    this._pendingPerms = new Map()

    // Track sdkSessionId once SDK reports it via `system/init`
    this.sdkSessionId = null

    // Run the query asynchronously
    this._runPromise = this._run()
  }

  // ----- streaming input plumbing -----

  _pushInputMessage(text) {
    if (this.closed) return
    if (this._inputResolver) {
      const r = this._inputResolver; this._inputResolver = null; r(text)
    } else {
      this._pendingInputs.push(text)
    }
  }

  async *_inputStream(initialPrompt) {
    if (initialPrompt) yield { type: 'user', message: { role: 'user', content: initialPrompt } }
    while (!this.closed) {
      let next
      if (this._pendingInputs.length > 0) next = this._pendingInputs.shift()
      else next = await new Promise((r) => { this._inputResolver = r })
      if (next == null) return
      yield { type: 'user', message: { role: 'user', content: next } }
    }
  }

  // ----- permission round-trip with the server -----

  _askPermission(toolName, input) {
    // Auto-allow if previously granted at session or always scope.
    if (this._sessionAllowedTools.has(toolName) ||
        this.manager?.isAlwaysAllowed(toolName)) {
      return Promise.resolve({ behavior: 'allow', updatedInput: input || {} })
    }

    const requestId = `perm_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this._pendingPerms.delete(requestId)
        // Default: deny on timeout
        resolve({ behavior: 'deny', message: 'Permission request timed out' })
      }, PERMISSION_TIMEOUT_MS)
      // Stash the original input + toolName so we can pass them back unchanged
      // on allow and apply scope decisions.
      this._pendingPerms.set(requestId, { resolve, reject, timer, input, toolName })
      this.emit({
        sessionId: this.id,
        type: 'permission_request',
        requestId,
        toolName,
        input
      })
    })
  }

  // Server pushes back the user's choice
  resolvePermission(requestId, decision) {
    const p = this._pendingPerms.get(requestId)
    if (!p) return false
    clearTimeout(p.timer)
    this._pendingPerms.delete(requestId)
    // decision: { allowed, scope: 'once'|'session'|'always', updatedInput? }
    if (decision.allowed) {
      // Honor scope so we don't ask again for the same tool.
      if (decision.scope === 'session' && p.toolName) {
        this._sessionAllowedTools.add(p.toolName)
      } else if (decision.scope === 'always' && p.toolName) {
        this.manager?.addAlwaysAllowed(p.toolName)
      }
      // SDK requires updatedInput to be a record. Default to the original
      // tool input when the user didn't modify anything.
      const updatedInput = (decision.updatedInput && typeof decision.updatedInput === 'object')
        ? decision.updatedInput
        : (p.input || {})
      p.resolve({ behavior: 'allow', updatedInput })
    } else {
      p.resolve({ behavior: 'deny', message: decision.message || 'User denied permission' })
    }
    return true
  }

  // ----- public commands from the uplink -----

  pushUserInput(text) {
    if (typeof text !== 'string' || !text.length) return
    this._pushInputMessage(text)
  }

  interrupt() {
    this.aborted = true
    // Pushing a special string so query is interrupted next turn.
    // The SDK has no first-class interrupt over streaming input; we push a
    // hint and let the next turn run a small NOP. For now we just close.
    this.close('interrupt')
  }

  close(reason = 'user_closed') {
    if (this.closed) return
    this.closed = true
    if (this._inputResolver) { const r = this._inputResolver; this._inputResolver = null; r(null) }
    // Reject pending permissions
    for (const [, p] of this._pendingPerms) {
      clearTimeout(p.timer)
      p.resolve({ behavior: 'deny', message: 'Session closed' })
    }
    this._pendingPerms.clear()
    this.emit({ sessionId: this.id, type: 'session_closed', reason })
  }

  // ----- main loop -----

  async _run() {
    // Tell the world the session is starting
    this.emit({ sessionId: this.id, type: 'session_started', name: this.name, folder: this.folder, startedAt: this.startedAt })

    const queryOptions = {
      settingSources: ['user', 'project'],
      permissionMode: 'default',
      canUseTool: async (toolName, input) => {
        return this._askPermission(toolName, input)
      }
    }
    if (this.folder) queryOptions.cwd = this.folder
    if (this.model) queryOptions.model = this.model
    if (this.resume) queryOptions.resume = this.resume
    // Stream partial messages so the browser can render assistant text as
    // it's produced rather than in a single thunk at end of turn.
    queryOptions.includePartialMessages = true
    // Pass the bundled native binary explicitly. The SDK's auto-resolution
    // sometimes fails on Windows when the agent process started before the
    // native package finished extracting; passing it here is deterministic.
    if (claudeExeInfo.exists) {
      queryOptions.pathToClaudeCodeExecutable = claudeExeInfo.exe
    }

    this.log(`session ${this.id} starting query: cwd=${queryOptions.cwd || '(none)'} ` +
      `pathToClaudeCodeExecutable=${queryOptions.pathToClaudeCodeExecutable || '(default)'} ` +
      `resume=${queryOptions.resume || '(no)'} `)
    // Emit a diagnostic event so we can read it from server logs.
    this.emit({
      sessionId: this.id,
      type: 'diag',
      claudeExeInfo,
      queryOptions: {
        cwd: queryOptions.cwd,
        model: queryOptions.model,
        resume: queryOptions.resume,
        pathToClaudeCodeExecutable: queryOptions.pathToClaudeCodeExecutable,
        settingSources: queryOptions.settingSources,
        permissionMode: queryOptions.permissionMode
      },
      env: {
        cwd: process.cwd(),
        ANTHROPIC_API_KEY_set: !!process.env.ANTHROPIC_API_KEY,
        nodeVersion: process.version
      }
    })

    try {
      for await (const msg of query({
        prompt: this._inputStream(null), // started without an initial prompt
        options: queryOptions
      })) {
        if (this.closed) break
        if (this.verbose) {
          try {
            const dump = JSON.stringify(msg)
            console.log(`[sdk ${this.id.slice(0, 8)}] ${dump.length > 1000 ? dump.slice(0, 1000) + '…(' + dump.length + ')' : dump}`)
          } catch { console.log(`[sdk ${this.id.slice(0, 8)}] (unserialisable)`, msg) }
        }
        this._forward(msg)
      }
    } catch (err) {
      this.log(`session ${this.id} error: ${err.message || err}`)
      if (err && err.stack) this.log(`session ${this.id} stack: ${err.stack.split('\n').slice(0, 5).join(' | ')}`)
      this.emit({ sessionId: this.id, type: 'error', message: String(err.message || err) })
    } finally {
      if (!this.closed) this.close('completed')
    }
  }

  // Translate one SDK message into one structured event for the server
  _forward(msg) {
    if (msg.type === 'system' && msg.subtype === 'init') {
      this.sdkSessionId = msg.session_id || null
      this.emit({
        sessionId: this.id,
        type: 'init',
        sdkSessionId: this.sdkSessionId,
        model: msg.model || null,
        cwd: msg.cwd || null
      })
      return
    }
    if (msg.type === 'system' && msg.subtype === 'compact_boundary') {
      const m = msg.compact_metadata || {}
      this.emit({ sessionId: this.id, type: 'compact', preTokens: m.pre_tokens, postTokens: m.post_tokens, durationMs: m.duration_ms, trigger: m.trigger })
      return
    }
    // Partial / streaming events from the Anthropic API. When
    // includePartialMessages is enabled the SDK yields these between full
    // 'assistant' messages so the client can render text as it lands.
    if (msg.type === 'stream_event' && msg.event) {
      this._handleStreamEvent(msg.event)
      return
    }
    if (msg.type === 'assistant' && msg.message?.content) {
      const messageId = msg.message.id || null
      for (const block of msg.message.content) {
        if (block.type === 'text' && block.text) {
          // Skip if we already streamed this block delta-by-delta — the
          // browser is showing the streamed copy with the same streamId.
          const streamId = messageId ? `${messageId}:text` : null
          if (streamId && this._streamedBlocks.has(streamId)) continue
          this.emit({ sessionId: this.id, type: 'assistant_text', text: block.text, streamId })
        } else if (block.type === 'thinking' && block.thinking) {
          const streamId = messageId ? `${messageId}:thinking` : null
          if (streamId && this._streamedBlocks.has(streamId)) continue
          this.emit({ sessionId: this.id, type: 'thinking', text: block.thinking, streamId })
        } else if (block.type === 'tool_use') {
          this.emit({ sessionId: this.id, type: 'tool_use', tool: block.name, input: block.input, callId: block.id })
        }
      }
      return
    }
    if (msg.type === 'user' && Array.isArray(msg.message?.content)) {
      for (const block of msg.message.content) {
        if (block.type === 'tool_result') {
          const out = typeof block.content === 'string'
            ? block.content
            : Array.isArray(block.content) ? block.content.map(c => c.text || '').join('') : ''
          this.emit({ sessionId: this.id, type: 'tool_result', callId: block.tool_use_id, content: out, isError: !!block.is_error })
        }
      }
      return
    }
    if (msg.type === 'result') {
      this.emit({
        sessionId: this.id,
        type: 'result',
        subtype: msg.subtype || null,
        usage: msg.usage || null,
        costUsd: msg.total_cost_usd ?? null
      })
      return
    }
  }

  // Translate Anthropic stream events (when includePartialMessages is true)
  // into our delta events. Each text/thinking content block becomes a
  // sequence of assistant_text/thinking events sharing a streamId; the
  // browser merges them by streamId and renders the latest.
  _handleStreamEvent(ev) {
    if (!ev || typeof ev !== 'object') return
    switch (ev.type) {
      case 'message_start':
        // New turn starting — clear dedup set so a fresh assistant message
        // can match the freshly-streamed blocks.
        this._streamedBlocks.clear()
        this._currentMessageId = ev.message?.id || null
        return
      case 'content_block_start': {
        const idx = ev.index ?? 0
        const block = ev.content_block || {}
        if (block.type === 'text' || block.type === 'thinking') {
          const streamId = this._currentMessageId
            ? `${this._currentMessageId}:${block.type}:${idx}`
            : `local:${this.id}:${block.type}:${idx}:${Date.now()}`
          this._streamingText.set(idx, { kind: block.type, text: '', streamId })
          // Emit an empty placeholder so the browser shows a row immediately.
          this.emit({
            sessionId: this.id,
            type: block.type === 'text' ? 'assistant_text' : 'thinking',
            text: '',
            streamId
          })
        }
        return
      }
      case 'content_block_delta': {
        const idx = ev.index ?? 0
        const slot = this._streamingText.get(idx)
        if (!slot) return
        const delta = ev.delta || {}
        if (delta.type === 'text_delta' && typeof delta.text === 'string') {
          slot.text += delta.text
          this.emit({ sessionId: this.id, type: 'assistant_text', text: slot.text, streamId: slot.streamId })
        } else if (delta.type === 'thinking_delta' && typeof delta.thinking === 'string') {
          slot.text += delta.thinking
          this.emit({ sessionId: this.id, type: 'thinking', text: slot.text, streamId: slot.streamId })
        }
        // input_json_delta for tool_use: ignore — we surface the final tool
        // input from the full assistant message instead.
        return
      }
      case 'content_block_stop': {
        const idx = ev.index ?? 0
        const slot = this._streamingText.get(idx)
        if (slot) {
          // Mark the matching block on the upcoming full assistant message
          // as already-streamed so we don't emit it twice.
          const baseStreamId = this._currentMessageId
            ? `${this._currentMessageId}:${slot.kind}`
            : null
          if (baseStreamId) this._streamedBlocks.add(baseStreamId)
          this._streamingText.delete(idx)
        }
        return
      }
      case 'message_stop':
        // Reset for next turn. _streamedBlocks is intentionally kept for the
        // duration of the message so the dedup against the full 'assistant'
        // message works; clearing it here would race the upcoming
        // 'assistant' yield. We clear on next message_start.
        return
    }
  }
}

class SessionManager {
  constructor({ emit, log, config, verbose }) {
    this.emit = emit
    this.log = log
    this.config = config  // shared agent config — used for persisted permissions
    this.verbose = !!verbose
    this.sessions = new Map()
  }

  // ----- shared permission state -----

  isAlwaysAllowed(toolName) {
    return Array.isArray(this.config?.alwaysAllowedTools)
      && this.config.alwaysAllowedTools.includes(toolName)
  }

  addAlwaysAllowed(toolName) {
    if (!this.config) return
    if (!Array.isArray(this.config.alwaysAllowedTools)) this.config.alwaysAllowedTools = []
    if (!this.config.alwaysAllowedTools.includes(toolName)) {
      this.config.alwaysAllowedTools.push(toolName)
      saveConfig(this.config)
    }
  }

  list() {
    return Array.from(this.sessions.values()).map(s => ({
      id: s.id,
      name: s.name,
      folder: s.folder,
      sdkSessionId: s.sdkSessionId,
      resume: s.resume,
      startedAt: s.startedAt,
      running: !s.closed
    }))
  }

  get(id) { return this.sessions.get(id) }

  create({ id, name, folder, model, resume }) {
    if (this.sessions.has(id)) return { error: 'session_exists' }
    const s = new Session({ id, name, folder, model, resume, emit: this.emit, log: this.log, manager: this, verbose: this.verbose })
    this.sessions.set(id, s)
    return s
  }

  delete(id) {
    const s = this.sessions.get(id)
    if (!s) return false
    s.close('deleted')
    this.sessions.delete(id)
    return true
  }

  closeAll() {
    for (const s of this.sessions.values()) s.close('shutdown')
    this.sessions.clear()
  }
}

module.exports = { SessionManager }
