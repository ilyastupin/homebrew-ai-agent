// uplink.js — agent ↔ server protocol over SSE+HTTP.
//
// Agent → Server (HTTP POSTs):
//   /api/claude/heartbeat        — periodic ping with agent metadata
//   /api/claude/agent-event      — structured event for one session
//   /api/claude/agent-response   — synchronous response to a server command
//
// Server → Agent (SSE):
//   /api/claude/agent-channel?token=…   — long-lived; receives commands.
//
// Commands the server may send:
//   create-session, delete-session, list-sessions,
//   input, permission-response, interrupt, get-past-sessions

const http = require('http')
const https = require('https')
const crypto = require('node:crypto')
const { execSync } = require('node:child_process')
const { saveConfig } = require('./config')
const sessionSettings = require('./session-settings')
const fileExplorer = require('./file-explorer')
const { claudeExeInfo } = require('./session-manager')

// Auth resolution order, highest to lowest:
//   1. process.env.ANTHROPIC_API_KEY
//   2. config.defaultApiKey
//   3. claude.ai OAuth (Windows Credential Manager / macOS Keychain)
//   4. server-provided fallback API key (only when 1-3 are absent)
function hasOAuthCredential() {
  try {
    if (process.platform === 'win32') {
      const out = execSync('cmdkey /list:"Claude Code-credentials"',
        { encoding: 'utf8', timeout: 4000 })
      return out.includes('Claude Code-credentials') && !out.includes('* NONE *')
    }
    if (process.platform === 'darwin') {
      execSync('security find-generic-password -s "Claude Code-credentials"',
        { encoding: 'utf8', timeout: 4000, stdio: ['ignore', 'pipe', 'ignore'] })
      return true
    }
  } catch { /* not found */ }
  return false
}

function createUplink(serverUrl, config, sessionManager, sessionStore) {
  const baseUrl = serverUrl.replace(/\/$/, '')

  // Use a dedicated agent for the long-lived SSE stream so default global-agent
  // socket-cleanup doesn't kill it. (See history of this file.)
  const sseAgent = new https.Agent({ keepAlive: true, keepAliveMsecs: 30000, maxSockets: 1, scheduling: 'lifo' })
  const sseHttpAgent = new http.Agent({ keepAlive: true, keepAliveMsecs: 30000, maxSockets: 1, scheduling: 'lifo' })

  let running = false
  let reconnectTimer = null
  let heartbeatInterval = null
  // Per-session POST ordering, so network reordering can't shuffle structured events.

  // ---------- HTTP POST helper ----------
  // Reject on any non-2xx so the event-queue retry path actually fires
  // when the ALB returns 502 during a backend redeploy. (The promise was
  // previously resolved with whatever body came back, which made the
  // queue think a 502 was a successful send and silently drop the event.)
  function post(path, body) {
    const url = `${baseUrl}${path}`
    const data = JSON.stringify(body)
    return new Promise((resolve, reject) => {
      const parsed = new URL(url)
      const mod = parsed.protocol === 'https:' ? https : http
      const req = mod.request(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(data),
          'x-agent-token': config.mineToken
        }
      }, (res) => {
        let buf = ''
        res.on('data', (c) => buf += c)
        res.on('end', () => {
          const status = res.statusCode || 0
          if (status >= 200 && status < 300) {
            try { resolve(JSON.parse(buf)) } catch { resolve(buf) }
          } else {
            reject(new Error(`HTTP ${status}`))
          }
        })
      })
      req.on('error', reject)
      req.setTimeout(15000, () => { req.destroy(); reject(new Error('timeout')) })
      req.write(data); req.end()
    })
  }

  // ---------- Auth mode ----------
  // Track auth state
  let authApplied = false
  let lastAllowOwnCreds = null
  // Save the env API key captured at startup so we can distinguish
  // a user-set key from the mineToken we may set ourselves.
  const envApiKeyAtStartup = process.env.ANTHROPIC_API_KEY || null

  function applyAuth(heartbeatResp) {
    const allowOwnCreds = !!heartbeatResp.allowOwnCreds
    const hasOwner = !!heartbeatResp.hasOwner

    if (lastAllowOwnCreds === allowOwnCreds && authApplied) return // no change
    lastAllowOwnCreds = allowOwnCreds
    authApplied = true

    const hasApiKey = !!(envApiKeyAtStartup || config.defaultApiKey)
    const hasOAuth = hasOAuthCredential()
    const hasLocalAuth = hasApiKey || hasOAuth

    if (hasLocalAuth && hasOwner && !allowOwnCreds) {
      // Hard fail — policy conflict
      console.error('')
      console.error('❌  Auth conflict: local Anthropic credentials detected but your')
      console.error('    project/account does not allow personal credentials.')
      console.error('    Options:')
      console.error('    • claude /logout                   (remove OAuth subscription)')
      console.error('    • unset ANTHROPIC_API_KEY          (remove API key)')
      console.error('    • Ask admin to enable allow_own_creds for your project')
      console.error('')
      process.exit(1)
    }

    if (hasLocalAuth && (!hasOwner || allowOwnCreds)) {
      // Use local auth directly — clear any proxy settings we may have set
      delete process.env.ANTHROPIC_BASE_URL
      // If ANTHROPIC_API_KEY is currently the mineToken (we set it), remove it
      // so the SDK falls back to OAuth or whatever real key is configured.
      if (process.env.ANTHROPIC_API_KEY === config.mineToken) {
        delete process.env.ANTHROPIC_API_KEY
      }
      const authDesc = hasApiKey
        ? `API key (${(config.defaultApiKey || envApiKeyAtStartup || '').slice(0, 12)}...)`
        : 'OAuth subscription (claude /login)'
      console.log(`[auth] Using local auth: ${authDesc}`)
    } else {
      // Proxy mode — route through server
      const proxyUrl = `${baseUrl}/api/anthropic-proxy`
      process.env.ANTHROPIC_BASE_URL = proxyUrl
      process.env.ANTHROPIC_API_KEY = config.mineToken
      console.log(`[auth] Using proxy: ${proxyUrl}`)
    }
  }

  // ---------- Heartbeat ----------
  async function sendHeartbeat() {
    try {
      const resp = await post('/api/claude/heartbeat', {
        token: config.mineToken,
        mineToken: config.mineToken,
        shareToken: config.shareToken,
        name: config.name,
        machineInfo: {
          platform: process.platform,
          arch: process.arch,
          hostname: require('os').hostname(),
          nodeVersion: process.version,
          claudeExe: (() => {
            try {
              const path = require('node:path')
              const fs = require('node:fs')
              const pkg = `@anthropic-ai/claude-agent-sdk-${process.platform}-${process.arch}`
              const p = require.resolve(`${pkg}/package.json`)
              const exe = path.join(path.dirname(p), process.platform === 'win32' ? 'claude.exe' : 'claude')
              return { path: exe, exists: fs.existsSync(exe) }
            } catch (e) { return { error: e.message } }
          })()
        }
      })
      // Apply auth mode based on server's response — runs on first heartbeat
      // and again if allowOwnCreds changes (e.g. admin updates project settings).
      if (typeof resp === 'object' && resp !== null && ('allowOwnCreds' in resp || 'hasOwner' in resp)) {
        applyAuth(resp)
      }
    } catch (err) {
      console.error('[uplink] Heartbeat failed:', err.message)
    }
  }

  // ---------- Outbound structured events ----------
  // Each emitted event gets a process-scoped sequence number. Three lines
  // share that number for visual grouping in the terminal:
  //   #0042 17:23:45 [abc12345] assistant_text "..."
  //   #0042 17:23:45 Sending... (assistant_text)
  //   #0042 17:23:46 Sent
  // — or 'Failed (reason) retrying...' on the unhappy path. Events go
  // through a single FIFO queue so a server outage during deploy doesn't
  // silently drop output: the head of the queue stays put until the POST
  // succeeds.
  const EVENT_QUEUE_CAP = 5000
  const eventQueue = []
  let flushing = false
  let retryDelayMs = 1000
  let eventCounter = 0

  function fmtEvent(event) {
    const sid = event.sessionId ? `[${String(event.sessionId).slice(0, 8)}]` : '[--------]'
    const sq = (s, max = 80) => !s ? '' : String(s).replace(/\s+/g, ' ').slice(0, max)
    let body
    switch (event.type) {
      case 'init':
        body = `init        model=${event.model || '?'} cwd=${event.cwd || '?'}`; break
      case 'compact':
        body = `compact     ${event.preTokens}→${event.postTokens} (${event.trigger || '?'})`; break
      case 'assistant_text':
        body = `assistant   "${sq(event.text, 100)}"`; break
      case 'thinking':
        body = `thinking    "${sq(event.text, 80)}"`; break
      case 'tool_use':
        body = `tool_use    ${event.tool}`; break
      case 'tool_result': {
        const txt = typeof event.content === 'string' ? event.content : ''
        body = `tool_result id=${(event.callId || '').slice(0, 8)} err=${!!event.isError} "${sq(txt, 80)}"`
        break
      }
      case 'result': {
        const u = event.usage || {}
        const cost = typeof event.costUsd === 'number' ? `$${event.costUsd.toFixed(4)}` : ''
        body = `result      ${event.subtype || ''} in=${u.input_tokens || 0} out=${u.output_tokens || 0} ${cost}`.trim()
        break
      }
      case 'session_started':
        body = `session_started name=${event.name || '?'} folder=${event.folder || '?'}`; break
      case 'session_closed':
        body = `session_closed reason=${event.reason || '?'}`; break
      case 'permission_request':
        body = `perm_req    tool=${event.toolName || '?'}`; break
      case 'error':
        body = `error       "${sq(event.message, 120)}"`; break
      case 'diag':
        body = 'diag'; break
      default:
        body = event.type || 'unknown'
    }
    return `${sid} ${body}`
  }

  function fmtNum(n) { return '#' + String(n).padStart(4, '0') }
  function ts() {
    const d = new Date()
    const p = (n) => String(n).padStart(2, '0')
    return `${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`
  }

  async function flushEventQueue() {
    if (flushing) return
    flushing = true
    while (eventQueue.length > 0) {
      const item = eventQueue[0]
      const tag = `${item.tagNum}`
      console.log(`${tag} ${ts()} Sending... (${item.event.type})`)
      try {
        await post('/api/claude/agent-event', { token: config.mineToken, ...item.event })
        console.log(`${tag} ${ts()} Sent`)
        eventQueue.shift()
        retryDelayMs = 1000
      } catch (err) {
        const wait = retryDelayMs
        retryDelayMs = Math.min(30000, retryDelayMs * 2)
        const reason = (err && err.message) || 'unknown'
        console.log(`${tag} ${ts()} Failed (${reason}) retrying in ${wait}ms…`)
        flushing = false
        setTimeout(flushEventQueue, wait)
        return
      }
    }
    flushing = false
  }

  function sendEventOrdered(event) {
    eventCounter++
    const n = eventCounter
    const tagNum = fmtNum(n)
    // Print the main line up front so the user sees what's about to be sent.
    console.log(`${tagNum} ${ts()} ${fmtEvent(event)}`)
    eventQueue.push({ n, tagNum, event })
    if (eventQueue.length > EVENT_QUEUE_CAP) {
      const dropped = eventQueue.length - EVENT_QUEUE_CAP
      eventQueue.splice(0, dropped)
      console.error(`[uplink] event queue overflow — dropped ${dropped} oldest events`)
    }
    flushEventQueue()
    return Promise.resolve()
  }

  // ---------- Synchronous response to a server command ----------
  function sendResponse(requestId, data) {
    if (!requestId) return Promise.resolve()
    return post('/api/claude/agent-response', {
      token: config.mineToken,
      requestId,
      data
    }).catch(() => {})
  }

  // ---------- Command channel (SSE) ----------
  function connectCommandChannel() {
    const url = `${baseUrl}/api/claude/agent-channel?token=${encodeURIComponent(config.mineToken)}`
    console.log(`[uplink] Connecting command channel to ${baseUrl}...`)

    const parsed = new URL(url)
    const isHttps = parsed.protocol === 'https:'
    const mod = isHttps ? https : http
    const agent = isHttps ? sseAgent : sseHttpAgent

    const req = mod.request(url, {
      method: 'GET',
      agent,
      timeout: 0,
      headers: {
        'Accept': 'text/event-stream',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
        'x-agent-token': config.mineToken
      }
    }, (res) => {
      if (res.statusCode !== 200) {
        console.error(`[uplink] Command channel returned ${res.statusCode}`)
        // Drain the body so the socket is released back to the pool
        // (with maxSockets:1 an undrained body would block all retries).
        res.resume()
        scheduleReconnect()
        return
      }
      console.log('[uplink] Command channel connected')

      if (res.socket?.setTimeout) {
        res.socket.setTimeout(0)
        res.socket.setKeepAlive(true, 30000)
      }

      let buffer = ''
      res.on('data', (chunk) => {
        buffer += chunk.toString()
        const parts = buffer.split('\n\n')
        buffer = parts.pop() || ''
        for (const part of parts) {
          const event = parseSSE(part)
          if (event) handleCommand(event)
        }
      })
      res.on('end', () => { console.log('[uplink] Channel ended (stream)'); if (running) scheduleReconnect() })
      res.on('close', () => { console.log('[uplink] Channel ended (socket close)'); if (running) scheduleReconnect() })
      res.on('error', (e) => { console.error(`[uplink] Channel error: ${e.message}`); if (running) scheduleReconnect() })
    })
    req.setTimeout(0)
    req.on('error', (e) => { console.error(`[uplink] Connect error: ${e.message}`); if (running) scheduleReconnect() })
    req.end()
  }

  function scheduleReconnect() {
    if (reconnectTimer) return
    console.log('[uplink] Reconnecting in 5s...')
    reconnectTimer = setTimeout(() => { reconnectTimer = null; if (running) connectCommandChannel() }, 5000)
  }

  function parseSSE(text) {
    let event = null
    let data = ''
    for (const line of text.split('\n')) {
      if (line.startsWith('event: ')) event = line.slice(7).trim()
      else if (line.startsWith('data: ')) data += line.slice(6)
    }
    if (!event) return null
    let parsed = {}
    if (data) { try { parsed = JSON.parse(data) } catch { parsed = { raw: data } } }
    return { event, data: parsed }
  }

  // ---------- Command dispatcher ----------
  async function handleCommand({ event, data }) {
    const requestId = data?.requestId

    try {
      switch (event) {
        case 'ping':
        case 'connected':
          break

        case 'create-session': {
          const id = data.sessionId || crypto.randomUUID()
          const result = sessionManager.create({
            id,
            name: data.name,
            folder: data.folder || null,
            model: data.model || null,
            effort: data.effort || null,
            resume: data.resume || null
          })
          if (result?.error) {
            await sendResponse(requestId, { error: result.error })
          } else {
            await sendResponse(requestId, { ok: true, sessionId: id, name: result.name })
          }
          break
        }

        case 'change-session-settings': {
          const s = sessionManager.get(data.sessionId)
          if (!s) { await sendResponse(requestId, { error: 'Session not found' }); break }
          const changed = s.applySettings({
            model: data.model,    // null clears override
            effort: data.effort   // null clears override
          })
          await sendResponse(requestId, {
            ok: true,
            changed,
            model: s.model,
            effort: s.effort,
            pendingRestart: !!s._pendingRestart
          })
          break
        }

        case 'delete-session': {
          // 'Soft' delete = close the in-memory session and let it become
          // a past entry. The JSONL transcript and sidecar stay on disk.
          const ok = sessionManager.delete(data.sessionId)
          await sendResponse(requestId, { deleted: ok })
          break
        }

        case 'rename-session': {
          // Set / clear the user-facing display title. Works for active
          // AND past (JSONL-only) sessions: if the id isn't in the active
          // map we treat it as the SDK session id and write the sidecar
          // directly (after verifying the JSONL exists).
          const result = sessionManager.rename(data.sessionId, data.title)
          await sendResponse(requestId, result)
          break
        }

        case 'purge-session': {
          // 'Hard' delete: close any in-memory session, unlink the SDK's
          // JSONL transcript, remove the sidecar. Permanent. Forks of
          // this session are NOT cascaded — they survive as orphans.
          const result = sessionManager.purge(data.sessionId)
          await sendResponse(requestId, result)
          break
        }

        case 'list-sessions': {
          await sendResponse(requestId, { sessions: sessionManager.list() })
          break
        }

        case 'input': {
          const s = sessionManager.get(data.sessionId)
          const attCount = Array.isArray(data.attachments) ? data.attachments.length : 0
          console.log(`[input] received: session=${data.sessionId?.slice(0,8)}… text-len=${String(data.text || '').length} attachments=${attCount}`)
          if (!s) {
            console.log(`[input] rejected: session ${data.sessionId?.slice(0,8)}… not found (text=${JSON.stringify(String(data.text || '').slice(0,60))})`)
            await sendResponse(requestId, { error: 'Session not found' })
            break
          }
          // Write attachments to <session_cwd>/.attachments/<safe_name> and
          // build a prompt prefix that points Claude at the saved paths.
          let promptText = String(data.text || '')
          const savedPaths = []
          if (Array.isArray(data.attachments) && data.attachments.length > 0) {
            const fs = require('node:fs')
            const path = require('node:path')
            const baseDir = s.folder
              ? path.join(s.folder, '.attachments')
              : path.join(require('node:os').tmpdir(), 'claude-attachments', s.id)
            try { fs.mkdirSync(baseDir, { recursive: true }) }
            catch (e) { console.error(`[input] could not create ${baseDir}: ${e.message}`) }
            for (const att of data.attachments) {
              try {
                const safe = String(att.name || 'file').replace(/[^\w.\-+@()\[\] ]+/g, '_').slice(0, 200) || 'file'
                let target = path.join(baseDir, safe)
                if (fs.existsSync(target)) {
                  const ext = path.extname(safe)
                  const stem = safe.slice(0, safe.length - ext.length)
                  target = path.join(baseDir, `${stem}-${Date.now()}${ext}`)
                }
                fs.writeFileSync(target, Buffer.from(String(att.base64 || ''), 'base64'))
                savedPaths.push(target)
                console.log(`[input] saved attachment: ${target} (${att.size} bytes)`)
              } catch (e) {
                console.error(`[input] failed to save ${att.name}: ${e.message}`)
              }
            }
            if (savedPaths.length > 0) {
              const list = savedPaths.map(p => `- ${p}`).join('\n')
              promptText = `[Attached files saved to disk — read them with the Read tool when relevant:\n${list}]\n\n${promptText}`
            }
          }
          s.pushUserInput(promptText)
          await sendResponse(requestId, { ok: true, savedPaths })
          break
        }

        case 'permission-response': {
          const s = sessionManager.get(data.sessionId)
          if (!s) { await sendResponse(requestId, { error: 'Session not found' }); break }
          s.resolvePermission(data.permRequestId, {
            allowed: !!data.allowed,
            scope: data.scope || 'once',
            updatedInput: data.updatedInput,
            message: data.message
          })
          await sendResponse(requestId, { ok: true })
          break
        }

        case 'interrupt': {
          const s = sessionManager.get(data.sessionId)
          if (!s) { await sendResponse(requestId, { error: 'Session not found' }); break }
          await s.interrupt()
          await sendResponse(requestId, { ok: true })
          break
        }

        case 'agent-status': {
          // Best-effort snapshot of the agent's Anthropic auth state.
          // The real `claude /status` is an interactive REPL slash
          // command — not callable from the CLI in headless mode — so
          // we surface what the agent KNOWS locally and call out the
          // bits we can't get without an interactive session.
          try {
            const fs = require('node:fs')
            const path = require('node:path')
            const os = require('node:os')
            const { execSync } = require('node:child_process')
            const pkg = require('./package.json')

            // Best-effort claude CLI version detection. The bundled
            // native binary supports --version reliably across releases.
            let cliVersion = null
            try {
              if (claudeExeInfo?.exists && claudeExeInfo.exe) {
                cliVersion = execSync(`"${claudeExeInfo.exe}" --version`,
                  { stdio: ['ignore', 'pipe', 'ignore'], timeout: 5000, encoding: 'utf8' }
                ).trim()
              }
            } catch { /* CLI may not support --version, leave null */ }

            // Auth detection mirrors what the SDK itself does. We
            // peek at ~/.claude/credentials and ~/.claude/settings.json
            // and the env vars without trying to validate them with
            // the API.
            const authSources = []
            const claudeDir = path.join(os.homedir(), '.claude')
            try {
              const credPath = path.join(claudeDir, 'credentials.json')
              if (fs.existsSync(credPath)) {
                const cred = JSON.parse(fs.readFileSync(credPath, 'utf8'))
                if (cred?.email) authSources.push({ kind: 'oauth', email: cred.email })
                else authSources.push({ kind: 'oauth' })
              }
            } catch { /* ignore */ }
            // macOS keychain: we can't read OAuth tokens directly, but
            // can detect their presence via `security find-generic-password`.
            // Skip on Windows — Credential Manager is queryable but
            // requires a wrapper we don't have. Just note 'maybe'.
            if (process.platform === 'darwin' && authSources.length === 0) {
              try {
                execSync('security find-generic-password -s "Claude Code-credentials"',
                  { stdio: ['ignore', 'ignore', 'ignore'], timeout: 3000 })
                authSources.push({ kind: 'oauth', source: 'macos-keychain' })
              } catch { /* not present */ }
            }
            if (process.env.ANTHROPIC_API_KEY) {
              authSources.push({
                kind: 'api_key',
                source: 'env',
                fingerprint: process.env.ANTHROPIC_API_KEY.slice(-6)
              })
            }
            if (config.defaultApiKey) {
              authSources.push({
                kind: 'api_key',
                source: 'agent.json',
                fingerprint: config.defaultApiKey.slice(-6)
              })
            }

            await sendResponse(requestId, {
              ok: true,
              agentVersion: pkg.version,
              cliVersion,
              claudeExe: {
                path: claudeExeInfo?.exe || null,
                exists: !!claudeExeInfo?.exists
              },
              serverUrl: config.serverUrl || null,
              hostname: os.hostname(),
              platform: process.platform,
              arch: process.arch,
              nodeVersion: process.version,
              uptimeSeconds: Math.round(process.uptime()),
              auth: authSources,
              note: 'Live rate-limit windows (the 5h / weekly counters claude /status shows) require an interactive REPL session and are not surfaced here. Visit claude.ai for a real-time quota view.'
            })
          } catch (err) {
            await sendResponse(requestId, { error: String(err?.message || err) })
          }
          break
        }

        case 'wake-session': {
          const s = sessionManager.get(data.sessionId)
          if (!s) { await sendResponse(requestId, { error: 'Session not found' }); break }
          const woke = await s.wake()
          await sendResponse(requestId, { ok: true, woke, alreadyRunning: !woke && !s.closed })
          break
        }

        case 'get-account-usage': {
          // Snapshot of AccountInfo (email/org/plan) + the per-bucket
          // rate-limit utilization the SDK has emitted so far. Empty
          // until the first session sends its init/rate_limit events.
          if (typeof sessionManager.getAccountUsage !== 'function') {
            await sendResponse(requestId, {
              error: 'Agent is too old — upgrade to 0.3.29+ for Account & Usage data.'
            })
            break
          }
          await sendResponse(requestId, sessionManager.getAccountUsage())
          break
        }

        case 'list-files': {
          const result = fileExplorer.listFiles(data.path || process.cwd())
          await sendResponse(requestId, result)
          break
        }

        case 'read-text-file': {
          const result = fileExplorer.readTextFile(data.path)
          await sendResponse(requestId, result)
          break
        }

        case 'download-file': {
          const result = fileExplorer.downloadFile(data.path)
          await sendResponse(requestId, result)
          break
        }

        case 'fork-session': {
          // Fork the SDK transcript at the source session's current tail.
          // The new JSONL is a physical copy of the parent (UUIDs remapped),
          // so future turns in the fork don't touch the parent's transcript.
          // Two-level hierarchy: the fork's parentSessionId points at the
          // ROOT ancestor — if the source itself was already a fork we
          // inherit its root, never letting the tree grow past depth 1.
          const sourceSession = sessionManager.get(data.sessionId)
          const sourceSdkId = sourceSession?.sdkSessionId || sourceSession?.resume || data.sessionId
          if (!sourceSdkId) {
            await sendResponse(requestId, { error: 'Source session has no SDK id yet — wait for the first init event before forking' })
            break
          }
          try {
            const sdk = require('@anthropic-ai/claude-agent-sdk')
            if (typeof sdk.forkSession !== 'function') {
              await sendResponse(requestId, { error: 'SDK does not expose forkSession in this version' })
              break
            }
            const result = await sdk.forkSession(sourceSdkId, data.title ? { title: data.title } : {})
            const newSdkId = result?.sessionId
            if (!newSdkId) {
              await sendResponse(requestId, { error: 'forkSession returned no sessionId' })
              break
            }
            // Determine the root parent. If the source already has a parent
            // (it's a fork itself), we point at its root — keeps the tree
            // capped at one level of nesting in the UI.
            let rootParentId = sourceSdkId
            try {
              const srcSidecar = sessionSettings.load(sourceSdkId)
              if (srcSidecar?.parentSessionId) rootParentId = srcSidecar.parentSessionId
            } catch { /* fresh source has no sidecar — fine */ }
            // Stash hierarchy + inherit model/effort so the picker state
            // carries over into the fork.
            const sourceSidecar = sessionSettings.load(sourceSdkId) || {}
            // Snapshot the parent's then-current totals as the fork's
            // baseline. The fork's transcript starts as a physical copy
            // of the parent's content up to this point — without the
            // baseline, summing the fork's JSONL would re-count every
            // inherited token. Browser subtracts this from the fork's
            // display total so it only shows what the fork itself spent.
            //
            // Edge case: if the source is itself a fork, we want OUR
            // baseline to be the source's CURRENT total (the source's
            // own prior baseline is already factored into its sidecar
            // metadata; computeTotals() reads the raw JSONL so it
            // captures the absolute spend up to fork time).
            const baseline = sessionStore.computeTotals(sourceSdkId)
            sessionSettings.save(newSdkId, {
              parentSessionId: rootParentId,
              model: sourceSidecar.model ?? null,
              effort: sourceSidecar.effort ?? null,
              forkBaseline: baseline || null
            })
            // Spin up an in-memory session that resumes the new JSONL so
            // the browser can immediately switch into it.
            const folder = sourceSession?.folder || data.folder || null
            const name = data.name || 'Fork'
            const created = sessionManager.create({
              id: newSdkId,
              name,
              folder,
              resume: newSdkId   // resume from the freshly-forked JSONL
            })
            if (created?.error) {
              await sendResponse(requestId, { error: created.error, sessionId: newSdkId })
              break
            }
            await sendResponse(requestId, {
              ok: true,
              sessionId: newSdkId,
              parentSessionId: rootParentId,
              name
            })
          } catch (err) {
            await sendResponse(requestId, { error: String(err?.message || err) })
          }
          break
        }

        case 'get-past-sessions': {
          const sessions = sessionStore?.listAll(20) || []
          await sendResponse(requestId, { sessions })
          break
        }

        case 'get-session-log': {
          // The browser may pass either our internal Session.id (active) or
          // an SDK session_id (past). Resolve to the SDK transcript id:
          //   1. session.sdkSessionId — assigned by the SDK after `init`
          //   2. session.resume       — the resumed-from SDK id (set on create)
          //   3. requested verbatim   — works for past sessions opened directly
          const requested = data.sessionId
          const limit = Number(data.limit) || 100
          const beforeIndex = typeof data.beforeIndex === 'number' ? data.beforeIndex : undefined
          const s = sessionManager.get?.(requested)
          const sdkId = s?.sdkSessionId || s?.resume || requested
          const result = sessionStore?.readSessionEvents?.(sdkId, { limit, beforeIndex })
            || { events: [], totalCount: 0, startIndex: 0, endIndex: 0 }
          console.log(`[uplink] get-session-log requested=${requested} sdkId=${sdkId} events=${result.events.length}/${result.totalCount} range=[${result.startIndex},${result.endIndex})`)
          await sendResponse(requestId, { sessionId: requested, sdkSessionId: sdkId, ...result })
          break
        }

        case 'browse-folders': {
          const fs = require('fs')
          const target = data.path || require('os').homedir()
          if (!fs.existsSync(target)) { await sendResponse(requestId, { error: 'Path does not exist' }); break }
          const entries = fs.readdirSync(target, { withFileTypes: true })
          const folders = entries.filter(e => e.isDirectory() && !e.name.startsWith('.')).map(e => e.name)
          await sendResponse(requestId, { path: target, folders })
          break
        }

        // mkdir -p the requested path so the new-session form can offer
        // 'folder doesn't exist — create it?' inline. Without this, the
        // SDK later spawn-fails with ENOENT and reports the misleading
        // 'Claude Code native binary not found' error.
        case 'create-folder': {
          const fs = require('fs')
          const target = data.path
          if (!target || typeof target !== 'string') {
            await sendResponse(requestId, { error: 'path required' })
            break
          }
          // Refuse non-absolute paths so we never silently mkdir under
          // the agent process's cwd (which is /).
          const path = require('path')
          if (!path.isAbsolute(target)) {
            await sendResponse(requestId, { error: 'absolute path required' })
            break
          }
          try {
            fs.mkdirSync(target, { recursive: true })
            await sendResponse(requestId, { ok: true, path: target })
          } catch (err) {
            await sendResponse(requestId, { error: err.message || String(err) })
          }
          break
        }

        case 'get-agent-settings': {
          const cfgKey = config.defaultApiKey
          const envKey = process.env.ANTHROPIC_API_KEY
          const source = cfgKey ? 'config' : envKey ? 'env' : 'none'
          const effective = cfgKey || envKey || null
          const masked = effective ? `${effective.slice(0, 10)}...${effective.slice(-4)}` : null
          await sendResponse(requestId, {
            name: config.name,
            mineToken: config.mineToken,
            shareToken: config.shareToken,
            hasDefaultApiKey: !!effective,
            defaultApiKeySource: source,
            defaultApiKeyMasked: masked
          })
          break
        }

        case 'rename-agent': {
          const next = String(data.name || '').trim()
          if (!next) { await sendResponse(requestId, { error: 'name required' }); break }
          config.name = next
          saveConfig(config)
          await sendResponse(requestId, { ok: true, name: config.name })
          break
        }

        case 'regenerate-share-token': {
          config.shareToken = `ctp_share_${crypto.randomBytes(18).toString('base64url')}`
          saveConfig(config)
          await sendResponse(requestId, { ok: true, shareToken: config.shareToken })
          break
        }

        case 'set-default-api-key': {
          const k = typeof data.apiKey === 'string' ? data.apiKey.trim() : ''
          if (k) {
            config.defaultApiKey = k
            process.env.ANTHROPIC_API_KEY = k
          } else {
            delete config.defaultApiKey
            // Leave process.env alone — clearing requires restart to "see" OAuth again.
          }
          saveConfig(config)
          const cfgKey = config.defaultApiKey
          const envKey = process.env.ANTHROPIC_API_KEY
          await sendResponse(requestId, {
            ok: true,
            hasDefaultApiKey: !!(cfgKey || envKey),
            defaultApiKeySource: cfgKey ? 'config' : envKey ? 'env' : 'none'
          })
          break
        }

        default:
          console.log(`[uplink] Unknown command: ${event}`)
          await sendResponse(requestId, { error: `Unknown command: ${event}` })
      }
    } catch (err) {
      console.error(`[uplink] Error handling ${event}: ${err.message}`)
      if (requestId) await sendResponse(requestId, { error: err.message })
    }
  }

  // ---------- Public API ----------
  return {
    start() {
      if (running) return
      running = true
      sendHeartbeat()
      heartbeatInterval = setInterval(sendHeartbeat, 30000)
      connectCommandChannel()
    },
    stop() {
      running = false
      if (heartbeatInterval) { clearInterval(heartbeatInterval); heartbeatInterval = null }
      if (reconnectTimer) { clearTimeout(reconnectTimer); reconnectTimer = null }
    },
    // Used by SessionManager via the emit callback we hand it
    emit: sendEventOrdered
  }
}

module.exports = { createUplink }
