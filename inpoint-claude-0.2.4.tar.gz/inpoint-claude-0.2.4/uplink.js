// uplink.js — agent ↔ server protocol over SSE+HTTP.
//
// Agent → Server (HTTP POSTs):
//   /api/claude/heartbeat        — periodic ping with agent metadata
//   /api/claude/agent-event      — structured event for one session
//   /api/claude/agent-response   — synchronous response to a server command
//
// Server → Agent (SSE):
//   /api/claude/agent-channel?token=…   — long-lived; receives commands.
//
// Commands the server may send:
//   create-session, delete-session, list-sessions,
//   input, permission-response, interrupt, get-past-sessions

const http = require('http')
const https = require('https')
const crypto = require('node:crypto')
const { execSync } = require('node:child_process')
const { saveConfig } = require('./config')

// Auth resolution order, highest to lowest:
//   1. process.env.ANTHROPIC_API_KEY
//   2. config.defaultApiKey
//   3. claude.ai OAuth (Windows Credential Manager / macOS Keychain)
//   4. server-provided fallback API key (only when 1-3 are absent)
function hasOAuthCredential() {
  try {
    if (process.platform === 'win32') {
      const out = execSync('cmdkey /list:"Claude Code-credentials"',
        { encoding: 'utf8', timeout: 4000 })
      return out.includes('Claude Code-credentials') && !out.includes('* NONE *')
    }
    if (process.platform === 'darwin') {
      execSync('security find-generic-password -s "Claude Code-credentials"',
        { encoding: 'utf8', timeout: 4000, stdio: ['ignore', 'pipe', 'ignore'] })
      return true
    }
  } catch { /* not found */ }
  return false
}

function createUplink(serverUrl, config, sessionManager, sessionStore) {
  const baseUrl = serverUrl.replace(/\/$/, '')

  // Use a dedicated agent for the long-lived SSE stream so default global-agent
  // socket-cleanup doesn't kill it. (See history of this file.)
  const sseAgent = new https.Agent({ keepAlive: true, keepAliveMsecs: 30000, maxSockets: 1, scheduling: 'lifo' })
  const sseHttpAgent = new http.Agent({ keepAlive: true, keepAliveMsecs: 30000, maxSockets: 1, scheduling: 'lifo' })

  let running = false
  let reconnectTimer = null
  let heartbeatInterval = null
  // Per-session POST ordering, so network reordering can't shuffle structured events.
  const sendGates = new Map() // sessionId -> Promise chain

  // ---------- HTTP POST helper ----------
  function post(path, body) {
    const url = `${baseUrl}${path}`
    const data = JSON.stringify(body)
    return new Promise((resolve, reject) => {
      const parsed = new URL(url)
      const mod = parsed.protocol === 'https:' ? https : http
      const req = mod.request(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(data),
          'x-agent-token': config.mineToken
        }
      }, (res) => {
        let buf = ''
        res.on('data', (c) => buf += c)
        res.on('end', () => { try { resolve(JSON.parse(buf)) } catch { resolve(buf) } })
      })
      req.on('error', reject)
      req.setTimeout(15000, () => { req.destroy(); reject(new Error('timeout')) })
      req.write(data); req.end()
    })
  }

  // ---------- Heartbeat ----------
  async function sendHeartbeat() {
    try {
      await post('/api/claude/heartbeat', {
        token: config.mineToken,
        mineToken: config.mineToken,
        shareToken: config.shareToken,
        name: config.name,
        machineInfo: {
          platform: process.platform,
          arch: process.arch,
          hostname: require('os').hostname(),
          nodeVersion: process.version,
          // Diagnostic — what the agent resolved for the SDK's native binary.
          claudeExe: (() => {
            try {
              const path = require('node:path')
              const fs = require('node:fs')
              const pkg = `@anthropic-ai/claude-agent-sdk-${process.platform}-${process.arch}`
              const p = require.resolve(`${pkg}/package.json`)
              const exe = path.join(path.dirname(p), process.platform === 'win32' ? 'claude.exe' : 'claude')
              return { path: exe, exists: fs.existsSync(exe) }
            } catch (e) { return { error: e.message } }
          })()
        }
      })
    } catch (err) {
      console.error('[uplink] Heartbeat failed:', err.message)
    }
  }

  // ---------- Outbound structured event with per-session ordering ----------
  function sendEventOrdered(event) {
    const sessionId = event.sessionId || '_'
    const prev = sendGates.get(sessionId) || Promise.resolve()
    const next = prev.then(() =>
      post('/api/claude/agent-event', { token: config.mineToken, ...event }).catch(() => {})
    )
    sendGates.set(sessionId, next)
    return next
  }

  // ---------- Synchronous response to a server command ----------
  function sendResponse(requestId, data) {
    if (!requestId) return Promise.resolve()
    return post('/api/claude/agent-response', {
      token: config.mineToken,
      requestId,
      data
    }).catch(() => {})
  }

  // ---------- Command channel (SSE) ----------
  function connectCommandChannel() {
    const url = `${baseUrl}/api/claude/agent-channel?token=${encodeURIComponent(config.mineToken)}`
    console.log(`[uplink] Connecting command channel to ${baseUrl}...`)

    const parsed = new URL(url)
    const isHttps = parsed.protocol === 'https:'
    const mod = isHttps ? https : http
    const agent = isHttps ? sseAgent : sseHttpAgent

    const req = mod.request(url, {
      method: 'GET',
      agent,
      timeout: 0,
      headers: {
        'Accept': 'text/event-stream',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
        'x-agent-token': config.mineToken
      }
    }, (res) => {
      if (res.statusCode !== 200) {
        console.error(`[uplink] Command channel returned ${res.statusCode}`)
        // Drain the body so the socket is released back to the pool
        // (with maxSockets:1 an undrained body would block all retries).
        res.resume()
        scheduleReconnect()
        return
      }
      console.log('[uplink] Command channel connected')

      if (res.socket?.setTimeout) {
        res.socket.setTimeout(0)
        res.socket.setKeepAlive(true, 30000)
      }

      let buffer = ''
      res.on('data', (chunk) => {
        buffer += chunk.toString()
        const parts = buffer.split('\n\n')
        buffer = parts.pop() || ''
        for (const part of parts) {
          const event = parseSSE(part)
          if (event) handleCommand(event)
        }
      })
      res.on('end', () => { console.log('[uplink] Channel ended (stream)'); if (running) scheduleReconnect() })
      res.on('close', () => { console.log('[uplink] Channel ended (socket close)'); if (running) scheduleReconnect() })
      res.on('error', (e) => { console.error(`[uplink] Channel error: ${e.message}`); if (running) scheduleReconnect() })
    })
    req.setTimeout(0)
    req.on('error', (e) => { console.error(`[uplink] Connect error: ${e.message}`); if (running) scheduleReconnect() })
    req.end()
  }

  function scheduleReconnect() {
    if (reconnectTimer) return
    console.log('[uplink] Reconnecting in 5s...')
    reconnectTimer = setTimeout(() => { reconnectTimer = null; if (running) connectCommandChannel() }, 5000)
  }

  function parseSSE(text) {
    let event = null
    let data = ''
    for (const line of text.split('\n')) {
      if (line.startsWith('event: ')) event = line.slice(7).trim()
      else if (line.startsWith('data: ')) data += line.slice(6)
    }
    if (!event) return null
    let parsed = {}
    if (data) { try { parsed = JSON.parse(data) } catch { parsed = { raw: data } } }
    return { event, data: parsed }
  }

  // ---------- Command dispatcher ----------
  async function handleCommand({ event, data }) {
    const requestId = data?.requestId

    try {
      switch (event) {
        case 'ping':
        case 'connected':
          break

        case 'create-session': {
          const id = data.sessionId || crypto.randomUUID()
          // Adopt the server's API key only as a last-resort fallback —
          // never override env, config, or claude.ai OAuth.
          if (data.serverDefaultApiKey
              && !process.env.ANTHROPIC_API_KEY
              && !config.defaultApiKey
              && !hasOAuthCredential()) {
            process.env.ANTHROPIC_API_KEY = data.serverDefaultApiKey
            console.log('[uplink] No local auth — using server-provided ANTHROPIC_API_KEY')
          }
          const result = sessionManager.create({
            id,
            name: data.name,
            folder: data.folder || null,
            model: data.model || null,
            resume: data.resume || null
          })
          if (result?.error) {
            await sendResponse(requestId, { error: result.error })
          } else {
            await sendResponse(requestId, { ok: true, sessionId: id, name: result.name })
          }
          break
        }

        case 'delete-session': {
          const ok = sessionManager.delete(data.sessionId)
          await sendResponse(requestId, { deleted: ok })
          break
        }

        case 'list-sessions': {
          await sendResponse(requestId, { sessions: sessionManager.list() })
          break
        }

        case 'input': {
          const s = sessionManager.get(data.sessionId)
          if (!s) { await sendResponse(requestId, { error: 'Session not found' }); break }
          s.pushUserInput(String(data.text || ''))
          await sendResponse(requestId, { ok: true })
          break
        }

        case 'permission-response': {
          const s = sessionManager.get(data.sessionId)
          if (!s) { await sendResponse(requestId, { error: 'Session not found' }); break }
          s.resolvePermission(data.permRequestId, {
            allowed: !!data.allowed,
            scope: data.scope || 'once',
            updatedInput: data.updatedInput,
            message: data.message
          })
          await sendResponse(requestId, { ok: true })
          break
        }

        case 'interrupt': {
          const s = sessionManager.get(data.sessionId)
          if (!s) { await sendResponse(requestId, { error: 'Session not found' }); break }
          s.interrupt()
          await sendResponse(requestId, { ok: true })
          break
        }

        case 'get-past-sessions': {
          const sessions = sessionStore?.listAll(20) || []
          await sendResponse(requestId, { sessions })
          break
        }

        case 'get-session-log': {
          // The browser may pass either our internal Session.id (active) or
          // the SDK session_id (past). Map active → SDK before reading the
          // JSONL; past sessions can be read directly.
          const requested = data.sessionId
          const limit = Number(data.limit) || 100
          let sdkId = requested
          const s = sessionManager.get?.(requested)
          if (s?.sdkSessionId) sdkId = s.sdkSessionId
          const events = sessionStore?.readSessionEvents?.(sdkId, limit) || []
          await sendResponse(requestId, { sessionId: requested, sdkSessionId: sdkId, events })
          break
        }

        case 'browse-folders': {
          const fs = require('fs')
          const target = data.path || require('os').homedir()
          if (!fs.existsSync(target)) { await sendResponse(requestId, { error: 'Path does not exist' }); break }
          const entries = fs.readdirSync(target, { withFileTypes: true })
          const folders = entries.filter(e => e.isDirectory() && !e.name.startsWith('.')).map(e => e.name)
          await sendResponse(requestId, { path: target, folders })
          break
        }

        case 'get-agent-settings': {
          const cfgKey = config.defaultApiKey
          const envKey = process.env.ANTHROPIC_API_KEY
          const source = cfgKey ? 'config' : envKey ? 'env' : 'none'
          const effective = cfgKey || envKey || null
          const masked = effective ? `${effective.slice(0, 10)}...${effective.slice(-4)}` : null
          await sendResponse(requestId, {
            name: config.name,
            mineToken: config.mineToken,
            shareToken: config.shareToken,
            hasDefaultApiKey: !!effective,
            defaultApiKeySource: source,
            defaultApiKeyMasked: masked
          })
          break
        }

        case 'rename-agent': {
          const next = String(data.name || '').trim()
          if (!next) { await sendResponse(requestId, { error: 'name required' }); break }
          config.name = next
          saveConfig(config)
          await sendResponse(requestId, { ok: true, name: config.name })
          break
        }

        case 'regenerate-share-token': {
          config.shareToken = `ctp_share_${crypto.randomBytes(18).toString('base64url')}`
          saveConfig(config)
          await sendResponse(requestId, { ok: true, shareToken: config.shareToken })
          break
        }

        case 'set-default-api-key': {
          const k = typeof data.apiKey === 'string' ? data.apiKey.trim() : ''
          if (k) {
            config.defaultApiKey = k
            process.env.ANTHROPIC_API_KEY = k
          } else {
            delete config.defaultApiKey
            // Leave process.env alone — clearing requires restart to "see" OAuth again.
          }
          saveConfig(config)
          const cfgKey = config.defaultApiKey
          const envKey = process.env.ANTHROPIC_API_KEY
          await sendResponse(requestId, {
            ok: true,
            hasDefaultApiKey: !!(cfgKey || envKey),
            defaultApiKeySource: cfgKey ? 'config' : envKey ? 'env' : 'none'
          })
          break
        }

        default:
          console.log(`[uplink] Unknown command: ${event}`)
          await sendResponse(requestId, { error: `Unknown command: ${event}` })
      }
    } catch (err) {
      console.error(`[uplink] Error handling ${event}: ${err.message}`)
      if (requestId) await sendResponse(requestId, { error: err.message })
    }
  }

  // ---------- Public API ----------
  return {
    start() {
      if (running) return
      running = true
      sendHeartbeat()
      heartbeatInterval = setInterval(sendHeartbeat, 30000)
      connectCommandChannel()
    },
    stop() {
      running = false
      if (heartbeatInterval) { clearInterval(heartbeatInterval); heartbeatInterval = null }
      if (reconnectTimer) { clearTimeout(reconnectTimer); reconnectTimer = null }
    },
    // Used by SessionManager via the emit callback we hand it
    emit: sendEventOrdered
  }
}

module.exports = { createUplink }
