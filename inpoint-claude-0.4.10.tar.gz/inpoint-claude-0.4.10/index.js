// Claude Terminal Proxy — agent process.
// Connects to an etra-ai server and runs Claude Agent SDK sessions on demand.

// Prefix every stdout / stderr line with HH:MM:SS so the agent's terminal
// reads chronologically. Lines that already start with '#NNNN' (per-event
// numbered traces from uplink.js) skip the prefix — those format their
// own timestamp inline so the number stays at the very left for grouping.
;(() => {
  const _log = console.log
  const _err = console.error
  const ts = () => {
    const d = new Date()
    const p = n => String(n).padStart(2, '0')
    return `${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`
  }
  const wrap = (orig) => (...args) => {
    const first = args[0]
    if (typeof first === 'string' && /^#\d{4}\b/.test(first)) {
      orig(...args)
    } else if (typeof first === 'string') {
      orig(`${ts()} ${first}`, ...args.slice(1))
    } else {
      orig(ts(), ...args)
    }
  }
  console.log = wrap(_log)
  console.error = wrap(_err)
})()

const { loadConfig, saveConfig } = require('./config')
const { createUplink } = require('./uplink')
const { SessionManager } = require('./session-manager')
const sessionStore = require('./session-store')
const { takeLock } = require('./single-instance')

function parseArgs(args) {
  // forceProxy defaults to TRUE — every claude call goes through
  // ai.inpoint.dev's /api/anthropic-proxy so the central BYOK key
  // resolver applies (centralised billing + access control). Use
  // --no-force-proxy ONLY for local development against the SDK
  // directly with your own OAuth creds.
  const opts = { server: null, apiKey: null, endpoint: null, showToken: false, verbose: false, forceProxy: true }
  for (let i = 0; i < args.length; i++) {
    switch (args[i]) {
      case '--server': opts.server = args[++i]; break
      case '--api-key': opts.apiKey = args[++i]; break
      case '--endpoint': opts.endpoint = args[++i]; break
      case '--token': opts.showToken = true; break
      case '-v':
      case '--verbose': opts.verbose = true; break
      case '--force-proxy': opts.forceProxy = true; break
      case '--no-force-proxy': opts.forceProxy = false; break
      case '--help': printUsage(); process.exit(0)
    }
  }
  return opts
}

function loadDotEnv() {
  const fs = require('fs')
  const path = require('path')
  const envPath = path.join(process.cwd(), '.env')
  if (!fs.existsSync(envPath)) return
  try {
    for (const line of fs.readFileSync(envPath, 'utf-8').split('\n')) {
      const trimmed = line.trim()
      if (!trimmed || trimmed.startsWith('#')) continue
      const m = trimmed.match(/^(?:export\s+)?([^=]+)=(.*)$/)
      if (!m) continue
      const key = m[1].trim()
      let value = m[2].trim()
      if ((value.startsWith('"') && value.endsWith('"')) ||
          (value.startsWith("'") && value.endsWith("'"))) {
        value = value.slice(1, -1)
      }
      if (!process.env[key]) process.env[key] = value
    }
  } catch { /* ignore */ }
}

function printUsage() {
  console.log(`
Claude Terminal Proxy — Claude Agent SDK bridge

Usage:
  node index.js --server <url>

Options:
  --server <url>      Server URL to connect to (e.g., https://ai.inpoint.dev)
                      Saved in config after first use.
  --api-key <key>     Optional ANTHROPIC_API_KEY fallback. If absent, the SDK
                      uses your claude.ai OAuth login from the OS keychain.
  --endpoint <url>    Override the Anthropic API base URL (sets ANTHROPIC_BASE_URL).
                      Use to route Claude calls through a custom proxy / mirror
                      / Bedrock-shim — e.g. when api.anthropic.com is blocked.
                      Example: --endpoint https://ai.inpoint.dev/api/anthropic-proxy
  --token             Print this agent's share token and exit.
  -v, --verbose       Log every message received from the Claude Agent SDK
                      to stdout. Useful for debugging streaming, tool use,
                      and permission round-trips.
  --force-proxy       (DEFAULT) Route every Claude call through the configured
                      server's /api/anthropic-proxy endpoint so the central
                      BYOK key resolver applies. The agent's local OAuth /
                      API key is ignored upstream — billing + access control
                      live on the server.
  --no-force-proxy    Opt out: use the agent's own local OAuth / API key for
                      every call, bypassing the server's BYOK resolver. For
                      local development only.
  --help              Show this message

Agent config is stored in ~/.claude-terminal-proxy/agent.json
Past Claude sessions are read from ~/.claude/projects/
`)
}

const opts = parseArgs(process.argv.slice(2))
loadDotEnv()
const config = loadConfig()

if (opts.showToken) {
  console.log(config.shareToken)
  process.exit(0)
}

if (!config.serverUrl && !opts.server) {
  config.serverUrl = 'https://ai.inpoint.dev'
}

if (opts.server) { config.serverUrl = opts.server; saveConfig(config) }
if (opts.apiKey) { config.defaultApiKey = opts.apiKey; saveConfig(config) }
// --endpoint persists in config so a restart keeps the override. Pass an
// empty string to clear: `inpoint-claude --endpoint ""`.
if (opts.endpoint !== null) {
  config.anthropicBaseUrl = opts.endpoint || null
  saveConfig(config)
}

// --force-proxy is a runtime-only flag (NOT persisted): tells applyAuth()
// in uplink to ignore local creds + server policy and always route every
// Claude call through the configured server's /api/anthropic-proxy.
config.forceProxy = !!opts.forceProxy

const serverUrl = config.serverUrl || null
const envApiKey = process.env.ANTHROPIC_API_KEY
const effectiveDefaultKey = config.defaultApiKey || envApiKey

// Banner. Auth + endpoint info is intentionally NOT printed here —
// the actual mode is decided post-heartbeat by applyAuth() in uplink
// (it depends on the server's allowOwnCreds policy + what credentials
// are present), and applyAuth prints `[auth] Using ...` once it
// resolves. Account identity (email / org / plan) prints `[account]`
// once the SDK reports it on the first session start. Printing
// configured-state lines here was misleading: e.g. having an
// --endpoint set + OAuth in keychain looks like "use proxy + use
// OAuth" but only ONE wins, and not in any obvious way.
console.log(`Claude Terminal Proxy`)
console.log(`  Name:        ${config.name}`)
console.log(`  Server:      ${serverUrl || '(not configured)'}`)
console.log(`  Mine token:  ${config.mineToken.slice(0, 15)}... (private — do not share)`)
console.log(`  Share token: ${config.shareToken}`)
console.log(`               ↑ paste into "Paste agent token…" at ${(serverUrl || 'https://ai.inpoint.dev').replace(/\/$/, '')}/claude`)
console.log()

if (!serverUrl) {
  console.error('Error: No server URL configured. Use --server <url>')
  process.exit(1)
}

// Singleton: kill any prior inpoint-claude that's still running on this
// machine. Two heartbeating with the same mineToken makes the server's
// SSE channel flap, which the user notices as "the chat keeps dropping
// out". Call only after we've decided to actually run — --token /
// --help / --show-token paths above already exited.
takeLock()

// If a default API key is configured, expose it to the SDK via env.
if (config.defaultApiKey && !process.env.ANTHROPIC_API_KEY) {
  process.env.ANTHROPIC_API_KEY = config.defaultApiKey
}

// Two-phase wiring: SessionManager needs an emit callback, but the uplink
// needs SessionManager to dispatch commands. Build uplink with a forwarder
// closure that resolves to SessionManager once it exists.
let sessionManager = null
// Proxy so the uplink can call any SessionManager method (current and
// future) without having to keep this list in sync. Necessary because
// `sessionManager` is `let` and only assigned AFTER createUplink — the
// uplink needs a stable reference. Each method goes through `this`-
// preserved binding so the SessionManager instance's `this` is correct.
const sessionManagerRef = new Proxy({}, {
  get(_target, prop) {
    if (!sessionManager) return undefined
    const v = sessionManager[prop]
    if (typeof v === 'function') return v.bind(sessionManager)
    return v
  }
})

const uplink = createUplink(serverUrl, config, sessionManagerRef, sessionStore)
sessionManager = new SessionManager({
  emit: (event) => uplink.emit(event),
  log: (msg) => console.log(`[session] ${msg}`),
  config,
  verbose: opts.verbose
})

uplink.start()

function shutdown() {
  console.log('\nShutting down...')
  uplink.stop()
  sessionManager.closeAll()
  process.exit(0)
}
process.on('SIGINT', shutdown)
process.on('SIGTERM', shutdown)
