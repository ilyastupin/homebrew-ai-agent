const fs = require('fs')
const path = require('path')
const crypto = require('crypto')
const os = require('os')

const CONFIG_DIR_NAME = '.claude-terminal-proxy'

function getConfigDir() {
  return path.join(os.homedir(), CONFIG_DIR_NAME)
}

function getConfigPath() {
  return path.join(getConfigDir(), 'agent.json')
}

function generateToken(prefix) {
  return `${prefix}_${crypto.randomBytes(18).toString('base64url')}`
}

function loadConfig() {
  const configPath = getConfigPath()
  fs.mkdirSync(getConfigDir(), { recursive: true })

  let config = null
  if (fs.existsSync(configPath)) {
    try { config = JSON.parse(fs.readFileSync(configPath, 'utf-8')) } catch { config = null }
  }

  if (!config) {
    config = {
      mineToken: generateToken('ctp_mine'),
      shareToken: generateToken('ctp_share'),
      name: os.hostname()
    }
    saveConfig(config)
  }

  let dirty = false
  if (!config.mineToken) { config.mineToken = generateToken('ctp_mine'); dirty = true }
  if (!config.shareToken) { config.shareToken = generateToken('ctp_share'); dirty = true }
  if (!config.name) { config.name = os.hostname(); dirty = true }
  if (!Array.isArray(config.alwaysAllowedTools)) { config.alwaysAllowedTools = []; dirty = true }
  // Drop legacy sessions field if present (sessions live in ~/.claude/projects/ now)
  if ('sessions' in config) { delete config.sessions; dirty = true }
  if (dirty) saveConfig(config)

  return config
}

function saveConfig(config) {
  fs.mkdirSync(getConfigDir(), { recursive: true })
  fs.writeFileSync(getConfigPath(), JSON.stringify(config, null, 2), 'utf-8')
}

function validateToken(config, token) {
  return token === config.mineToken || token === config.shareToken
}

module.exports = { loadConfig, saveConfig, validateToken, getConfigDir, getConfigPath }
