// single-instance.js
// Ensure only one inpoint-claude agent runs per machine. On startup,
// check ~/.claude-terminal-proxy/agent.lock. If a previous agent's PID
// is still alive, send it SIGTERM and wait briefly for it to exit
// before installing our own PID. On graceful exit (SIGINT / SIGTERM /
// process.exit) we unlink the lockfile so the next start doesn't waste
// a moment poking a PID that's already gone.
//
// Cross-platform notes:
//   • os.homedir() works everywhere (mac/linux/windows).
//   • process.kill(pid, 0) is the standard "is this PID alive?" test —
//     supported by libuv on Windows too.
//   • SIGTERM on Windows is treated as SIGKILL by libuv (process dies
//     immediately). That's acceptable here — we want it gone.

const fs = require('node:fs')
const path = require('node:path')
const os = require('node:os')

const LOCK_DIR = path.join(os.homedir(), '.claude-terminal-proxy')
const LOCK_FILE = path.join(LOCK_DIR, 'agent.lock')

function isAlive(pid) {
  try { process.kill(pid, 0); return true }
  catch (err) {
    // ESRCH = no such process. EPERM = process exists but we can't
    // signal it (e.g. running as different user) — counts as alive.
    return err && err.code === 'EPERM'
  }
}

function sleepSync(ms) {
  // Tiny synchronous wait — only used at startup before we hand control
  // to the event loop. Atomics.wait is the cross-platform way to block.
  const buf = new SharedArrayBuffer(4)
  Atomics.wait(new Int32Array(buf), 0, 0, ms)
}

/**
 * Take the singleton lock. Kills any prior live agent first.
 * Idempotent on stale lockfiles. Should be called once at startup
 * BEFORE we start listening on anything.
 */
function takeLock() {
  let priorPid = null
  try {
    const raw = fs.readFileSync(LOCK_FILE, 'utf8').trim()
    const n = parseInt(raw, 10)
    if (Number.isFinite(n) && n > 0 && n !== process.pid) priorPid = n
  } catch { /* no lockfile — fresh start */ }

  if (priorPid && isAlive(priorPid)) {
    console.log(`[single-instance] killing prior agent pid=${priorPid}`)
    try { process.kill(priorPid, 'SIGTERM') } catch { /* race */ }
    // Give it up to ~2 s to exit gracefully. Poll every 100 ms.
    const deadline = Date.now() + 2000
    while (Date.now() < deadline && isAlive(priorPid)) {
      sleepSync(100)
    }
    if (isAlive(priorPid)) {
      // Stubborn — escalate.
      console.log(`[single-instance] prior agent still up — SIGKILL`)
      try { process.kill(priorPid, 'SIGKILL') } catch { /* gone */ }
      sleepSync(200)
    }
  }

  try { fs.mkdirSync(LOCK_DIR, { recursive: true }) } catch {}
  try { fs.writeFileSync(LOCK_FILE, String(process.pid)) }
  catch (err) {
    console.error(`[single-instance] could not write lockfile: ${err.message}`)
  }

  // Best-effort cleanup. Multiple handlers are OK — they all unlink.
  const cleanup = () => { try { fs.unlinkSync(LOCK_FILE) } catch {} }
  process.on('exit', cleanup)
  // Also handle the common interrupt signals so a Ctrl-C path runs
  // cleanup before exit. SIGTERM is the signal we send to predecessors.
  for (const sig of ['SIGINT', 'SIGTERM', 'SIGHUP']) {
    process.on(sig, () => { cleanup(); process.exit(0) })
  }
}

module.exports = { takeLock, LOCK_FILE }
