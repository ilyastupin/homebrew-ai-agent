// session-settings.js
// Per-session sidecar storing { model, effort } the user picked from the
// web UI's settings popover. Lives next to the agent config so it survives
// agent restarts. The session-id is the SDK session id (same as the JSONL
// transcript filename), so the override automatically follows the
// conversation across resumes.

const fs = require('node:fs')
const path = require('node:path')
const os = require('node:os')

const DIR = path.join(os.homedir(), '.claude-terminal-proxy', 'sessions')

function file(sessionId) { return path.join(DIR, `${sessionId}.json`) }

function load(sessionId) {
  if (!sessionId) return null
  try {
    const raw = fs.readFileSync(file(sessionId), 'utf8')
    const json = JSON.parse(raw)
    if (json && typeof json === 'object') return json
  } catch { /* missing / invalid — ignore */ }
  return null
}

// Merges `settings` into the existing sidecar so callers can update one
// field at a time (e.g. only `title`) without clobbering the others
// (`model`, `effort`, `parentSessionId`, …). Pass an explicit `null` to
// clear a stored field — keys are still preserved as null in that case
// rather than being dropped.
function save(sessionId, settings) {
  if (!sessionId) return false
  try {
    fs.mkdirSync(DIR, { recursive: true })
    const existing = load(sessionId) || {}
    const merged = { ...existing, ...settings }
    fs.writeFileSync(file(sessionId), JSON.stringify(merged, null, 2))
    return true
  } catch (err) {
    console.error('[session-settings] save failed:', err.message)
    return false
  }
}

function remove(sessionId) {
  if (!sessionId) return
  try { fs.unlinkSync(file(sessionId)) } catch { /* ok if absent */ }
}

module.exports = { load, save, remove }
