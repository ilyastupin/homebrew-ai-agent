// model-windows.js
// Persisted per-model contextWindow / maxOutputTokens cache.
//
// The SDK only emits `modelUsage` (which carries contextWindow) on live
// `result` messages. The JSONL transcript never gets it, so a session
// resumed/refreshed has no way to know that e.g. claude-opus-4-7 is the
// 1M variant rather than the 200k one. We populate this cache from live
// result events as they flow through, and read it during replay.

const fs = require('node:fs')
const path = require('node:path')
const os = require('node:os')

const FILE = path.join(os.homedir(), '.claude-terminal-proxy', 'model-windows.json')

let cache = null

function load() {
  if (cache) return cache
  try {
    const raw = fs.readFileSync(FILE, 'utf8')
    cache = JSON.parse(raw) || {}
  } catch {
    cache = {}
  }
  return cache
}

function save() {
  if (!cache) return
  try {
    fs.mkdirSync(path.dirname(FILE), { recursive: true })
    fs.writeFileSync(FILE, JSON.stringify(cache, null, 2))
  } catch { /* ignore */ }
}

function record(model, info) {
  if (!model || !info) return
  const cw = typeof info.contextWindow === 'number' ? info.contextWindow : null
  const mo = typeof info.maxOutputTokens === 'number' ? info.maxOutputTokens : null
  if (!cw && !mo) return
  load()
  const prev = cache[model] || {}
  const next = { ...prev }
  if (cw) next.contextWindow = cw
  if (mo) next.maxOutputTokens = mo
  if (next.contextWindow !== prev.contextWindow || next.maxOutputTokens !== prev.maxOutputTokens) {
    cache[model] = next
    save()
  }
}

function recordModelUsage(modelUsage) {
  if (!modelUsage || typeof modelUsage !== 'object') return
  for (const [model, info] of Object.entries(modelUsage)) {
    record(model, info)
  }
}

function get(model) {
  load()
  return cache[model] || null
}

function asModelUsage(model) {
  const info = get(model)
  if (!info) return null
  return { [model]: info }
}

module.exports = { record, recordModelUsage, get, asModelUsage }
