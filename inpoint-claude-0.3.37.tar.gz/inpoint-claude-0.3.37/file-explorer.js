// file-explorer.js
// Agent-side filesystem browser for the web UI's Files drawer.
// Three operations:
//   listFiles(path)      — directory listing with metadata
//   readTextFile(path)   — read up to 5 MB of text; sniff binary so the
//                          UI never tries to render a blob as text
//   downloadFile(path)   — read up to 25 MB and base64 the bytes back so
//                          the browser can build a Blob and trigger
//                          the standard download flow
//
// Path scope: anything the agent's user can read on the host. The web UI
// sits behind requireApiAuth + agent-access check, so this surface is
// no broader than the existing Bash + Read tools the SDK already exposes
// through the chat — same security boundary, different shape.

const fs = require('node:fs')
const path = require('node:path')

const TEXT_PEEK_BYTES = 8192
const TEXT_MAX_BYTES = 5 * 1024 * 1024
const DOWNLOAD_MAX_BYTES = 25 * 1024 * 1024

// Light extension-driven mime guess. For download the value goes into
// the Blob's type so the browser can offer a sensible "Save as…" dialog
// and inline-render images. For text, mime drives the MD-toggle path
// only. Unknown extensions get the conservative octet-stream default.
const MIME_BY_EXT = {
  '.txt': 'text/plain',
  '.md': 'text/markdown',
  '.markdown': 'text/markdown',
  '.json': 'application/json',
  '.jsonl': 'application/json',
  '.js': 'text/javascript',
  '.mjs': 'text/javascript',
  '.cjs': 'text/javascript',
  '.ts': 'text/typescript',
  '.tsx': 'text/typescript',
  '.jsx': 'text/javascript',
  '.html': 'text/html',
  '.htm': 'text/html',
  '.css': 'text/css',
  '.scss': 'text/css',
  '.csv': 'text/csv',
  '.tsv': 'text/tab-separated-values',
  '.xml': 'application/xml',
  '.yaml': 'application/yaml',
  '.yml': 'application/yaml',
  '.toml': 'application/toml',
  '.sh': 'text/x-shellscript',
  '.py': 'text/x-python',
  '.rb': 'text/x-ruby',
  '.go': 'text/x-go',
  '.rs': 'text/x-rust',
  '.java': 'text/x-java',
  '.c': 'text/x-c',
  '.h': 'text/x-c',
  '.cpp': 'text/x-c++',
  '.cs': 'text/x-csharp',
  '.sql': 'application/sql',
  '.log': 'text/plain',
  '.env': 'text/plain',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.webp': 'image/webp',
  '.svg': 'image/svg+xml',
  '.bmp': 'image/bmp',
  '.ico': 'image/x-icon',
  '.pdf': 'application/pdf',
  '.zip': 'application/zip',
  '.tar': 'application/x-tar',
  '.gz': 'application/gzip'
}

function mimeOf(name) {
  const ext = path.extname(name || '').toLowerCase()
  return MIME_BY_EXT[ext] || 'application/octet-stream'
}

// Heuristic: a buffer is "probably text" if it has no NUL bytes and the
// utf-8 decoding produces few-to-zero replacement characters. Catches
// the common cases (source code, config, log, csv) and correctly bins
// out images / archives / executables.
function isProbablyText(buf) {
  if (!buf || buf.length === 0) return true
  for (let i = 0; i < buf.length; i++) {
    if (buf[i] === 0) return false
  }
  try {
    const s = buf.toString('utf8')
    if (s.length === 0) return true
    let bad = 0
    for (let i = 0; i < s.length; i++) if (s.charCodeAt(i) === 0xFFFD) bad++
    return (bad / s.length) < 0.02
  } catch { return false }
}

function listFiles(dirPath) {
  const abs = path.resolve(dirPath || '/')
  let entries
  try {
    entries = fs.readdirSync(abs, { withFileTypes: true })
  } catch (err) {
    return { error: err.message, absolutePath: abs }
  }
  const out = []
  for (const e of entries) {
    const full = path.join(abs, e.name)
    let size = 0
    let mtime = 0
    let type = e.isDirectory() ? 'dir' : (e.isFile() ? 'file' : 'other')
    try {
      // lstat would surface symlinks separately, but the typical user
      // wants the symlink target; fall back to stat for size/mtime.
      const st = fs.statSync(full)
      size = st.size
      mtime = st.mtimeMs
      if (e.isSymbolicLink()) type = st.isDirectory() ? 'dir' : 'file'
    } catch { /* permission denied / dangling symlink — keep zeros */ }
    out.push({
      name: e.name,
      type,
      size,
      mtime,
      isHidden: e.name.startsWith('.')
    })
  }
  const parent = path.dirname(abs)
  return {
    absolutePath: abs,
    parent: parent === abs ? null : parent,
    entries: out
  }
}

function readTextFile(filePath) {
  const abs = path.resolve(filePath)
  let st
  try { st = fs.statSync(abs) }
  catch (err) { return { error: err.message } }
  if (st.isDirectory()) return { error: 'Not a file' }

  const name = path.basename(abs)
  const meta = { name, size: st.size, mtime: st.mtimeMs, mime: mimeOf(abs), absolutePath: abs }

  if (st.size > TEXT_MAX_BYTES) {
    return { ok: true, isText: null, tooLarge: true, ...meta, limit: TEXT_MAX_BYTES }
  }

  let buf
  try { buf = fs.readFileSync(abs) }
  catch (err) { return { error: err.message } }

  const peek = buf.length > TEXT_PEEK_BYTES ? buf.subarray(0, TEXT_PEEK_BYTES) : buf
  const isText = isProbablyText(peek)
  if (!isText) return { ok: true, isText: false, ...meta }
  return { ok: true, isText: true, ...meta, text: buf.toString('utf8') }
}

function downloadFile(filePath) {
  const abs = path.resolve(filePath)
  let st
  try { st = fs.statSync(abs) }
  catch (err) { return { error: err.message } }
  if (st.isDirectory()) return { error: 'Cannot download a directory' }
  if (st.size > DOWNLOAD_MAX_BYTES) {
    return {
      error: `File too large to download in-browser (${Math.round(st.size / 1024 / 1024)} MB > ${DOWNLOAD_MAX_BYTES / 1024 / 1024} MB cap)`,
      size: st.size
    }
  }
  let buf
  try { buf = fs.readFileSync(abs) }
  catch (err) { return { error: err.message } }
  return {
    ok: true,
    name: path.basename(abs),
    size: st.size,
    mtime: st.mtimeMs,
    mime: mimeOf(abs),
    base64: buf.toString('base64')
  }
}

module.exports = {
  listFiles,
  readTextFile,
  downloadFile,
  TEXT_MAX_BYTES,
  DOWNLOAD_MAX_BYTES
}
