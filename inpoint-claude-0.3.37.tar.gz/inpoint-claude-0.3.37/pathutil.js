// Translate Windows paths to WSL paths when the agent runs under WSL.
// C:\Users\ai\Desktop  ->  /mnt/c/Users/ai/Desktop
// Leaves Linux/Mac paths untouched.

function windowsToWsl(p) {
  if (!p || typeof p !== 'string') return p
  // C:\... or c:/... or c:\...
  const m = p.match(/^([A-Za-z]):[\\/](.*)$/)
  if (!m) return p
  const drive = m[1].toLowerCase()
  const rest = m[2].replace(/\\/g, '/')
  return `/mnt/${drive}/${rest}`
}

// Detect whether we are running inside WSL so we know whether to translate
function isWsl() {
  if (process.platform !== 'linux') return false
  try {
    const fs = require('fs')
    if (fs.existsSync('/proc/sys/fs/binfmt_misc/WSLInterop')) return true
    const osRelease = fs.readFileSync('/proc/version', 'utf8')
    return /microsoft/i.test(osRelease)
  } catch {
    return false
  }
}

// Normalize a path supplied by the web UI. On WSL, translate Windows-style paths.
function normalizeFolderPath(p) {
  if (isWsl()) return windowsToWsl(p)
  return p
}

module.exports = { windowsToWsl, isWsl, normalizeFolderPath }
