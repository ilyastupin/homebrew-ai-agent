// session-manager.js
// One Session = one ongoing Claude Agent SDK conversation.
// The session owns:
//   - a streaming-input async iterator we can push user messages into
//   - a queue of structured events to forward upstream
//   - a permission-pending registry (requestId → resolver) for canUseTool round-trips
//
// emit(event) — caller-supplied function for forwarding events to the server.
//
// Events have shape: { sessionId, type, ...fields }
// Inbound commands handled by Session: input, permissionResponse, interrupt, close.

const path = require('node:path')
const fs = require('node:fs')
const { query } = require('@anthropic-ai/claude-agent-sdk')
const { saveConfig } = require('./config')
const modelWindows = require('./model-windows')
const sessionSettings = require('./session-settings')

// Read the agent-SDK version from its package.json so we can mirror what
// the SDK does internally (it sets `process.env.CLAUDE_AGENT_SDK_VERSION`
// inside its query() function — too late for callers who pass options.env,
// because the SDK then clones the caller-supplied env instead of process.env
// and the version env never reaches the spawned claude CLI).
//
// Without this var the spawned claude CLI takes a different fetch code path
// that converts streaming /v1/messages POSTs into body-less GETs, producing
// 405 Method Not Allowed on every BYOK proxy call. Setting it here on the
// per-session env we hand to query() restores the working code path.
//
// We can't `require('@anthropic-ai/claude-agent-sdk/package.json')` directly
// because the SDK's package.json `exports` map whitelists only the entry
// points (`.`, `./browser`, `./bridge`, `./assistant`, `./sdk-tools`) and
// blocks `./package.json` with ERR_PACKAGE_PATH_NOT_EXPORTED. Walk the
// filesystem instead — works regardless of the exports map.
const CLAUDE_AGENT_SDK_VERSION = (() => {
  try {
    let dir = __dirname
    while (dir !== path.dirname(dir)) {
      const candidate = path.join(dir, 'node_modules', '@anthropic-ai', 'claude-agent-sdk', 'package.json')
      if (fs.existsSync(candidate)) {
        const v = JSON.parse(fs.readFileSync(candidate, 'utf8')).version
        return typeof v === 'string' && v.length > 0 ? v : null
      }
      dir = path.dirname(dir)
    }
    return null
  } catch {
    return null
  }
})()

const PERMISSION_TIMEOUT_MS = 5 * 60 * 1000

// Resolve the bundled Claude Code native binary at agent startup so we can
// pass it explicitly to query() and surface useful errors if it's missing.
function resolveBundledClaudeExe() {
  const platform = process.platform
  const arch = process.arch
  const ext = platform === 'win32' ? '.exe' : ''
  const pkg = `@anthropic-ai/claude-agent-sdk-${platform}-${arch}`
  try {
    // The native package only ships claude.exe + package.json — its package.json
    // has no main, so resolve via require.resolve on package.json.
    const pkgPath = require.resolve(`${pkg}/package.json`)
    const dir = path.dirname(pkgPath)
    const exe = path.join(dir, `claude${ext}`)
    return { exe, exists: fs.existsSync(exe), pkg, dir }
  } catch (err) {
    return { exe: null, exists: false, pkg, error: err.message }
  }
}

const claudeExeInfo = resolveBundledClaudeExe()
console.log(`[session-manager] claudeExe ${claudeExeInfo.exe || '(unresolved)'} exists=${claudeExeInfo.exists}` +
  (claudeExeInfo.error ? ` error=${claudeExeInfo.error}` : ''))
console.log(`[session-manager] sdkVersion ${CLAUDE_AGENT_SDK_VERSION || '(unresolved)'}`)

// Read effortLevel from user (~/.claude/settings.json) + project (<cwd>/.claude/settings.json).
// Project wins over user when both are present. Returns one of 'low'|'medium'|
// 'high'|'xhigh'|'max'|<integer> or null if nothing valid is configured.
const VALID_EFFORTS = new Set(['low', 'medium', 'high', 'xhigh', 'max'])
function readEffortPreference(cwd) {
  const homedir = require('node:os').homedir()
  const candidates = [
    path.join(homedir, '.claude', 'settings.json'),
    cwd ? path.join(cwd, '.claude', 'settings.json') : null
  ].filter(Boolean)
  let chosen = null
  for (const p of candidates) {
    try {
      const raw = fs.readFileSync(p, 'utf8')
      const json = JSON.parse(raw)
      const v = json && json.effortLevel
      if (typeof v === 'string' && VALID_EFFORTS.has(v)) chosen = v
      else if (typeof v === 'number' && Number.isFinite(v)) chosen = v
    } catch { /* missing / invalid — ignore */ }
  }
  return chosen
}

// Single-line summary for one SDK message — used in --verbose mode to
// produce a compact terminal trace whose labels match the chat-log UI.
const VERBOSE_LINE_MAX = 200
function squish(s, max = 80) {
  if (s == null) return ''
  return String(s).replace(/\s+/g, ' ').slice(0, max)
}
/** Save a title and read it back. ok only if the file now holds exactly
 *  that title (null = cleared). */
function writeTitleVerified(key, title) {
  if (!key) return { ok: false, error: 'no session key' }
  if (!sessionSettings.save(key, { title })) return { ok: false, error: 'write failed' }
  const back = sessionSettings.load(key)
  const onDisk = back && typeof back.title === 'string' && back.title ? back.title : null
  if (onDisk !== title) return { ok: false, error: `read back ${JSON.stringify(onDisk)}` }
  return { ok: true }
}

function shortSdkSummary(msg) {
  if (!msg || typeof msg !== 'object') return ''
  let line = ''
  switch (msg.type) {
    case 'system':
      if (msg.subtype === 'init') line = `init        model=${msg.model || '?'} cwd=${msg.cwd || '?'}`
      else if (msg.subtype === 'compact_boundary') {
        const m = msg.compact_metadata || {}
        line = `compact     ${m.pre_tokens}→${m.post_tokens} tokens (${m.trigger || '?'})`
      }
      else if (msg.subtype === 'status') line = `status      ${msg.status || '?'}`
      else if (msg.subtype === 'model_refusal_fallback') {
        line = `REFUSAL     ${msg.original_model || '?'} → ${msg.fallback_model || '?'} (${msg.api_refusal_category || 'no category'}, scope=${msg.scope || 'session'})`
      }
      else if (msg.subtype === 'model_refusal_no_fallback') {
        line = `REFUSAL     ${msg.original_model || '?'} refused, no fallback (${msg.api_refusal_category || 'no category'})`
      }
      else line = `system      ${msg.subtype || '?'}`
      break
    case 'stream_event': {
      const ev = msg.event || {}
      switch (ev.type) {
        case 'message_start':
          line = `msg_start   id=${(ev.message?.id || '').slice(0, 16)} model=${ev.message?.model || ''}`
          break
        case 'content_block_start':
          line = `block_start idx=${ev.index} type=${ev.content_block?.type || '?'}`
          break
        case 'content_block_delta': {
          const d = ev.delta || {}
          if (d.type === 'text_delta') line = `text_delta  idx=${ev.index} "${squish(d.text, 100)}"`
          else if (d.type === 'thinking_delta') line = `think_delta idx=${ev.index} "${squish(d.thinking, 80)}"`
          else if (d.type === 'input_json_delta') line = `input_json  idx=${ev.index} "${squish(d.partial_json, 80)}"`
          else if (d.type === 'signature_delta') line = `sig_delta   idx=${ev.index}`
          else line = `${d.type || 'delta'}    idx=${ev.index}`
          break
        }
        case 'content_block_stop':
          line = `block_stop  idx=${ev.index}`
          break
        case 'message_delta':
          line = `msg_delta   stop=${ev.delta?.stop_reason || '?'} out=${ev.usage?.output_tokens ?? '?'}`
          break
        case 'message_stop':
          line = `msg_stop`
          break
        default:
          line = `stream      ${ev.type || '?'}`
      }
      break
    }
    case 'assistant': {
      const blocks = msg.message?.content || []
      const summaries = blocks.map(b => {
        if (b.type === 'text') return `text "${squish(b.text, 100)}"`
        if (b.type === 'thinking') return 'thinking'
        if (b.type === 'tool_use') return `tool_use ${b.name}`
        return b.type
      }).join(' + ')
      line = `assistant   ${summaries}`
      break
    }
    case 'user': {
      const c = msg.message?.content
      if (Array.isArray(c)) {
        line = 'user        ' + c.map(b => {
          if (b.type === 'tool_result') {
            const txt = typeof b.content === 'string'
              ? b.content
              : Array.isArray(b.content) ? b.content.map(x => x.text || '').join('') : ''
            return `tool_result id=${(b.tool_use_id || '').slice(0, 8)} err=${!!b.is_error} "${squish(txt, 80)}"`
          }
          if (b.type === 'text') return `text "${squish(b.text, 100)}"`
          return b.type
        }).join(' + ')
      } else {
        line = `user        "${squish(c, 100)}"`
      }
      break
    }
    case 'result': {
      const u = msg.usage || {}
      const cost = typeof msg.total_cost_usd === 'number' ? `$${msg.total_cost_usd.toFixed(4)}` : ''
      line = `result      ${msg.subtype || ''} in=${u.input_tokens || 0} out=${u.output_tokens || 0} ${cost}`.trim()
      break
    }
    case 'rate_limit_event':
      line = `rate_limit  ${msg.rate_limit_info?.status || '?'}`
      break
    default:
      line = msg.type || 'unknown'
  }
  return line.length > VERBOSE_LINE_MAX ? line.slice(0, VERBOSE_LINE_MAX - 1) + '…' : line
}

class Session {
  constructor({ id, name, folder, model, effort, resume, sessionEnv, emit, log, manager, verbose }) {
    this.id = id
    // Per-session env overrides — pushed by the server when running in
    // BYOK / proxy mode (mode 2). Typically:
    //   { ANTHROPIC_API_KEY: '<ctp_csess_…>', ANTHROPIC_BASE_URL: '<proxy>' }
    // The SDK's query() forwards options.env to the spawned claude.exe
    // child process. We MERGE with process.env at run time (not here)
    // because Node's spawn replaces the entire env when one is provided
    // — passing only sessionEnv would strip PATH and break the spawn.
    this.sessionEnv = (sessionEnv && typeof sessionEnv === 'object') ? sessionEnv : null
    // Leave name empty if the user didn't provide one — pushUserInput
    // will auto-name from the first prompt. Falls back to a literal
    // 'Untitled' only when neither name nor folder is available
    // (basically never — folder is required by the dialog).
    this.name = name || (folder ? '' : 'Untitled')
    this.folder = folder || null
    this.resume = resume || null  // SDK session_id of a past JSONL transcript to continue

    // Per-session model + effort overrides. The web UI's settings popover
    // writes these into a sidecar (~/.claude-terminal-proxy/sessions/<id>.json
    // or sessions/<sdkSessionId>.json). Sidecar wins over constructor args
    // so a resumed session keeps whatever the user picked last time.
    const persistedKey = this.resume || this.id
    const persisted = sessionSettings.load(persistedKey) || {}
    this.model = (persisted.model !== undefined ? persisted.model : model) || null
    this.effort = (persisted.effort !== undefined ? persisted.effort : effort) || null
    // User-supplied display title (set via the pencil icon in the sidebar).
    // Overrides the auto-derived `name`. Stored in the sidecar so it
    // survives an agent restart and follows resumes by SDK session id.
    this.title = (typeof persisted.title === 'string' && persisted.title) ? persisted.title : null

    // When the user changes settings via the popover we save the sidecar
    // and flip _pendingRestart. The next pushUserInput tears down the
    // active SDK query() and starts a new one with the new options +
    // resume=<sdkSessionId>, so the conversation continues seamlessly.
    this._pendingRestart = false
    this._restarting = false

    this.emit = emit
    this.log = log || (() => {})
    this.manager = manager  // SessionManager — exposes shared permission state
    this.verbose = !!verbose  // Dump every SDK message to stdout when true

    // Tools the user allowed for the duration of THIS session.
    this._sessionAllowedTools = new Set()

    // Streaming-text accumulators, keyed by content block index. The SDK
    // can deliver assistant text either as one complete message or, when
    // includePartialMessages is enabled, as a sequence of text_delta events.
    // We keep the running text per block so the browser can render it
    // smoothly without having to know about deltas.
    this._streamingText = new Map()
    // Message IDs whose text/thinking blocks we already streamed via deltas.
    // When the SDK later yields the full 'assistant' message with the same
    // id we skip its text/thinking blocks (still emit tool_use) so the chat
    // log doesn't show the same answer twice.
    this._streamedMessageIds = new Set()
    // The current message_id from message_start; used to build streamIds.
    this._currentMessageId = null

    this.startedAt = Date.now()
    this.lastInputAt = Date.now()  // bumped on each pushUserInput; drives idle sweep
    // Has the user sent at least one prompt through this session? Used by
    // SessionManager.findIdleEmpty() to dedupe "+ New Session" multi-clicks
    // (an empty session in the same folder is reused instead of creating
    // a fresh duplicate). Distinct from `_autoNamed` which only flips for
    // sessions that started with a non-empty `name`.
    this._hasUserInput = false
    // lastActivityAt is what the sidebar sorts on. For a resumed session we
    // seed it from the JSONL's mtime so a click-to-resume doesn't make the
    // session jump to the top of the list with no real activity. Bumped on
    // every user input AND on every SDK event so an in-progress conversation
    // stays at the top while it's actively producing output.
    this.lastActivityAt = this.startedAt
    if (this.resume) {
      try {
        const sessionStore = require('./session-store')
        const file = sessionStore.findTranscript(this.resume)
        if (file) {
          const st = require('node:fs').statSync(file)
          if (st.mtimeMs) this.lastActivityAt = st.mtimeMs
        }
      } catch { /* fall back to startedAt */ }
    }
    this.pendingToolCount = 0  // tool_use without matching tool_result yet — don't auto-close while non-zero
    this.closed = false
    this.aborted = false

    // Streaming input plumbing
    this._pendingInputs = []
    this._inputResolver = null

    // Pending permission requests: requestId → { resolve, reject, timer }
    this._pendingPerms = new Map()

    // Track sdkSessionId once SDK reports it via `system/init`
    this.sdkSessionId = null

    // Occupancy of the context window as of the last message_start.
    // Survives across turns within the session, so the meter still has a
    // value between turns; reset by a compaction the same way the real
    // window is, because the next message_start reports the new size.
    this._lastContextTokens = null

    // Run the query asynchronously
    this._runPromise = this._run()
  }

  // ----- streaming input plumbing -----

  _pushInputMessage(text) {
    if (this.closed) return
    if (this._inputResolver) {
      const r = this._inputResolver; this._inputResolver = null; r(text)
    } else {
      this._pendingInputs.push(text)
    }
  }

  async *_inputStream(initialPrompt) {
    if (initialPrompt) yield { type: 'user', message: { role: 'user', content: initialPrompt } }
    while (!this.closed) {
      let next
      if (this._pendingInputs.length > 0) next = this._pendingInputs.shift()
      else next = await new Promise((r) => { this._inputResolver = r })
      if (next == null) return
      yield { type: 'user', message: { role: 'user', content: next } }
    }
  }

  // ----- permission round-trip with the server -----

  _askPermission(toolName, input) {
    // Auto-allow if previously granted at session or always scope.
    if (this._sessionAllowedTools.has(toolName) ||
        this.manager?.isAlwaysAllowed(toolName)) {
      return Promise.resolve({ behavior: 'allow', updatedInput: input || {} })
    }

    const requestId = `perm_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this._pendingPerms.delete(requestId)
        // Default: deny on timeout
        resolve({ behavior: 'deny', message: 'Permission request timed out' })
      }, PERMISSION_TIMEOUT_MS)
      // Stash the original input + toolName so we can pass them back unchanged
      // on allow and apply scope decisions.
      this._pendingPerms.set(requestId, { resolve, reject, timer, input, toolName })
      this.emit({
        sessionId: this.id,
        type: 'permission_request',
        requestId,
        toolName,
        input
      })
    })
  }

  // Server pushes back the user's choice
  resolvePermission(requestId, decision) {
    const p = this._pendingPerms.get(requestId)
    if (!p) return false
    clearTimeout(p.timer)
    this._pendingPerms.delete(requestId)
    // decision: { allowed, scope: 'once'|'session'|'always', updatedInput? }
    if (decision.allowed) {
      // Honor scope so we don't ask again for the same tool.
      if (decision.scope === 'session' && p.toolName) {
        this._sessionAllowedTools.add(p.toolName)
      } else if (decision.scope === 'always' && p.toolName) {
        this.manager?.addAlwaysAllowed(p.toolName)
      }
      // SDK requires updatedInput to be a record. Default to the original
      // tool input when the user didn't modify anything.
      const updatedInput = (decision.updatedInput && typeof decision.updatedInput === 'object')
        ? decision.updatedInput
        : (p.input || {})
      p.resolve({ behavior: 'allow', updatedInput })
    } else {
      p.resolve({ behavior: 'deny', message: decision.message || 'User denied permission' })
    }
    return true
  }

  // ----- public commands from the uplink -----

  async pushUserInput(text) {
    if (typeof text !== 'string' || !text.length) return
    this._hasUserInput = true
    this.lastInputAt = Date.now()
    this.lastActivityAt = this.lastInputAt
    // Auto-name the session from its FIRST user prompt. We treat the
    // session as "unnamed" if name is empty or matches the folder
    // basename — the latter is the legacy fallback the dialog used to
    // submit when the user didn't fill the field. New blank-named
    // sessions are nameless from the start, but we keep both checks so
    // older agents/sessions also pick up a real name on first send.
    if (!this._autoNamed && this.name) {
      const looksUnnamed = !this.name.trim()
        || this.name === 'Untitled'
        || this.name === '(new session)'
        || (this.folder && this.name === path.basename(this.folder))
      if (looksUnnamed) {
        const derived = text.replace(/\s+/g, ' ').trim().slice(0, 60)
        if (derived) {
          this.name = derived
          this._autoNamed = true
          this.emit({ sessionId: this.id, type: 'session_renamed', name: this.name })
          this.log(`session ${this.id.slice(0, 8)} auto-named from first prompt: "${this.name}"`)
        }
      } else {
        this._autoNamed = true  // had an explicit name from the start
      }
    }
    // If the user changed model/effort via the popover, the new options
    // can't be applied to the in-flight query — tear it down and restart
    // with resume=<sdkSessionId> + the new options before pushing the new
    // message into the fresh stream.
    if (this._pendingRestart && !this._restarting) {
      try { await this._restartQuery() }
      catch (err) { this.log(`session ${this.id.slice(0, 8)} restart failed: ${err?.message || err}`) }
    }
    this._pushInputMessage(text)
  }

  // Update model and/or effort for this session. Saved to the sidecar so
  // it survives an agent restart, and scheduled to apply on the next
  // user input via _restartQuery(). Pass `null` to clear an override and
  // fall back to settings.json defaults.
  applySettings({ model, effort }) {
    let changed = false
    if (model !== undefined) {
      const next = model || null
      if (next !== this.model) { this.model = next; changed = true }
    }
    if (effort !== undefined) {
      const next = effort || null
      if (next !== this.effort) { this.effort = next; changed = true }
    }
    if (!changed) return false
    const key = this.sdkSessionId || this.resume || this.id
    sessionSettings.save(key, { model: this.model, effort: this.effort })
    this._pendingRestart = true
    this.log(`session ${this.id.slice(0, 8)} settings update: model=${this.model || '(default)'} effort=${this.effort || '(default)'} — applies on next input`)
    this.emit({
      sessionId: this.id,
      type: 'settings_changed',
      model: this.model,
      effort: this.effort,
      pending: true
    })
    return true
  }

  // Set the user-facing display title (pencil icon in the sidebar).
  // Pass an empty string or null to clear and fall back to the auto-name.
  // Persists to the sidecar so it survives agent restarts. Does NOT
  // touch the active SDK query — title is purely a display label.
  /** Write the title to the sidecar, read it back, and report what is on
   *  disk. The sidecar is the only source of truth for titles: list()
   *  re-reads it on every call, so a title that didn't reach the disk shows
   *  up as an error here instead of living in memory until the session is
   *  evicted or the agent restarts and then silently vanishing (2026-10-07:
   *  "Artur" / "INPoint Pricing" reverted to their first prompts). */
  applyTitle(title) {
    const next = (typeof title === 'string' && title.trim()) ? title.trim().slice(0, 200) : null
    const key = this.sdkSessionId || this.resume || this.id
    const written = writeTitleVerified(key, next)
    this.log(`session ${this.id.slice(0, 8)} title ${written.ok ? 'saved' : 'NOT SAVED'} key=${key} title=${JSON.stringify(next)}${written.error ? ' error=' + written.error : ''}`)
    if (!written.ok) return { ok: false, error: written.error, key }
    this.title = next
    this.emit({
      sessionId: this.id,
      type: 'session_renamed',
      name: this.name,
      title: this.title
    })
    return { ok: true, key, title: next }
  }

  // Tear down the current SDK query and start a new one with the same
  // sdkSessionId so the conversation continues from the JSONL transcript
  // — applies queued model/effort changes mid-conversation.
  async _restartQuery() {
    if (this._restarting || this.closed) return
    this._restarting = true
    const sdkId = this.sdkSessionId || this.resume
    try {
      // Abort the in-flight turn so the for-await loop exits promptly.
      if (this._query?.interrupt) {
        try { await this._query.interrupt() } catch { /* best-effort */ }
      }
      // Push a sentinel so the input iterator returns even if no turn was active.
      this._pushInputMessage(null)
      try { await this._runPromise } catch { /* swallow — we're tearing down */ }
    } finally {
      // Re-arm transient state and start a fresh query() with the new options.
      this._pendingRestart = false
      this._restarting = false
      this.closed = false
      this.aborted = false
      this._streamingText = new Map()
      this._streamedMessageIds = new Set()
      this._currentMessageId = null
      this._pendingInputs = []
      this._inputResolver = null
      this._query = null
      this.resume = sdkId || this.resume  // continue the same JSONL
      this._runPromise = this._run()
    }
  }

  // Wake an idle-timed-out (or otherwise closed) session by starting a
  // fresh query() that resumes the same JSONL transcript. The session
  // object stays under the same id so the chat log keeps appending to
  // the existing event stream — no flicker, no new entry in the sidebar.
  // No-op if the session is still running.
  async wake() {
    if (!this.closed) return false
    if (this._restarting) return false
    this.log(`session ${this.id.slice(0, 8)} waking up — resuming from ${this.sdkSessionId || this.resume || '(no sdk id)'}`)
    // Reset transient state and arm a new run() with resume=<sdk id>.
    this.closed = false
    this.aborted = false
    this._streamingText = new Map()
    this._streamedMessageIds = new Set()
    this._currentMessageId = null
    this._pendingInputs = []
    this._inputResolver = null
    this._query = null
    this.resume = this.sdkSessionId || this.resume
    this.lastInputAt = Date.now()  // bump so the idle sweep doesn't immediately re-close
    this._runPromise = this._run()
    return true
  }

  // Real interrupt: call the Query's native interrupt() so the in-flight
  // turn aborts. The session itself stays alive — the iterator yields a
  // result with stop_reason='interrupted', and the next user input
  // starts a new turn.
  async interrupt() {
    if (!this._query || typeof this._query.interrupt !== 'function') {
      // Older SDK or query not yet started — fall back to closing.
      this.close('interrupt')
      return
    }
    try {
      await this._query.interrupt()
      this.log(`session ${this.id.slice(0, 8)} interrupted current turn`)
    } catch (err) {
      this.log(`session ${this.id.slice(0, 8)} interrupt error: ${err?.message || err}`)
    }
  }

  close(reason = 'user_closed') {
    if (this.closed) return
    this.closed = true
    if (this._inputResolver) { const r = this._inputResolver; this._inputResolver = null; r(null) }
    // Reject pending permissions
    for (const [, p] of this._pendingPerms) {
      clearTimeout(p.timer)
      p.resolve({ behavior: 'deny', message: 'Session closed' })
    }
    this._pendingPerms.clear()
    this.emit({ sessionId: this.id, type: 'session_closed', reason })
  }

  // ----- main loop -----

  async _run() {
    // Tell the world the session is starting
    this.emit({ sessionId: this.id, type: 'session_started', name: this.name, folder: this.folder, startedAt: this.startedAt })

    const queryOptions = {
      settingSources: ['user', 'project'],
      permissionMode: 'default',
      canUseTool: async (toolName, input) => {
        // AskUserQuestion: SDK built-in tool that opens a CLI TUI prompt.
        // We're headless (web UI), so we deny it and command the model
        // to re-ask the question(s) in plain text. The denial message
        // becomes the tool_result content the model reads — explicit
        // "do NOT pick a default" wording is required, otherwise the
        // model softly chooses the option labelled "(Recommended)" from
        // the input it just generated, defeating the point.
        if (toolName === 'AskUserQuestion') {
          return {
            behavior: 'deny',
            message:
              'AskUserQuestion is unavailable in this UI. ' +
              'Re-ask the same question(s) as plain text in your next reply, ' +
              'list each option with its label and description, then STOP. ' +
              'Do NOT pick a default. Do NOT pick the option labelled "Recommended". ' +
              'Wait for the user to type their choice before doing anything else.'
          }
        }
        return this._askPermission(toolName, input)
      }
    }
    if (this.folder) queryOptions.cwd = this.folder
    if (this.model) queryOptions.model = this.model
    if (this.resume) queryOptions.resume = this.resume
    // Effort: per-session override (set via web UI's settings popover) wins
    // over file-level defaults from ~/.claude/settings.json + <cwd>/.claude.
    // 'max' is only valid as a runtime option — settings.json's persisted
    // schema rejects it — so we always read+forward ourselves.
    const effort = this.effort || readEffortPreference(this.folder)
    if (effort) queryOptions.effort = effort
    // Stream partial messages so the browser can render assistant text as
    // it's produced rather than in a single thunk at end of turn.
    queryOptions.includePartialMessages = true
    // BYOK (mode 2) per-session env. The server hands the agent
    // ANTHROPIC_API_KEY=<ctp_csess_…> + ANTHROPIC_BASE_URL=<proxy URL>.
    // We forward via queryOptions.env so multiple concurrent sessions on
    // the same agent can use different upstream credentials cleanly —
    // no global process.env mutation, no race between sessions for the
    // shared env slot. node:child_process.spawn replaces the entire
    // env when `env` is set, so we MERGE with the parent process's env
    // first (PATH, HOME, … all still need to flow through).
    if (this.sessionEnv) {
      // Mirror the agent SDK's internal env injection. The SDK sets
      // CLAUDE_AGENT_SDK_VERSION on process.env inside query() AFTER it
      // has already cloned options.env, so passing options.env effectively
      // strips the version env. Without it, the spawned claude CLI sends
      // a body-less GET on /v1/messages and gets 405. Setting it here keeps
      // both paths (default env / our own env) on the working code path.
      const sdkEnv = CLAUDE_AGENT_SDK_VERSION
        ? { CLAUDE_AGENT_SDK_VERSION }
        : {}
      // DEBUG (0.4.5): turn on the SDK's own debug-to-stderr mode in the
      // child so we can see exactly what HTTP method/URL the spawned
      // claude binary is preparing. Captured below via options.stderr.
      const debugEnv = process.env.INPOINT_CLAUDE_DEBUG_SPAWN === '0'
        ? {}
        : { DEBUG_CLAUDE_AGENT_SDK: '1' }
      queryOptions.env = { ...process.env, ...sdkEnv, ...debugEnv, ...this.sessionEnv }
      this.log(`session ${this.id.slice(0, 8)} using per-session env (${Object.keys(this.sessionEnv).join(',')})` +
        ` sdkVersion=${CLAUDE_AGENT_SDK_VERSION || '(unresolved)'}` +
        ` debugSpawn=${debugEnv.DEBUG_CLAUDE_AGENT_SDK ? 'on' : 'off'}`)
    }

    // Always pin the binary explicitly. The agent-SDK auto-resolves the
    // bundled native package, but resolution can race with extraction on
    // Windows-cold-start, so passing it here is deterministic. The bundled
    // binary works fine for both proxy-mode and direct-mode now that we
    // inject CLAUDE_AGENT_SDK_VERSION above (the previous "GET 405" symptom
    // was caused by the missing env var, not by Bun-vs-Node).
    if (claudeExeInfo.exists) {
      queryOptions.pathToClaudeCodeExecutable = claudeExeInfo.exe
    }

    // DEBUG (0.4.5): forward the spawned claude binary's stderr through
    // our log so the agent terminal AND the server log show exactly what
    // the binary thinks it's doing — particularly the HTTP request line
    // it's about to send (method, url, body bytes). Behind a flag so an
    // operator can disable if the volume is annoying. Trims long lines
    // so a stack trace doesn't blow the log file.
    if (process.env.INPOINT_CLAUDE_DEBUG_SPAWN !== '0') {
      const sid = this.id.slice(0, 8)
      queryOptions.stderr = (line) => {
        const trimmed = String(line || '').replace(/\s+$/, '')
        if (!trimmed) return
        // Cap each line at 600 chars so a runaway log doesn't fill disk.
        const safe = trimmed.length > 600 ? trimmed.slice(0, 600) + '…[trunc]' : trimmed
        this.log(`[claude.stderr ${sid}] ${safe}`)
      }
    }

    this.log(`session ${this.id} starting query: cwd=${queryOptions.cwd || '(none)'} ` +
      `effort=${queryOptions.effort || '(sdk default)'} ` +
      `pathToClaudeCodeExecutable=${queryOptions.pathToClaudeCodeExecutable || '(default)'} ` +
      `resume=${queryOptions.resume || '(no)'} `)
    // Emit a diagnostic event so we can read it from server logs.
    this.emit({
      sessionId: this.id,
      type: 'diag',
      claudeExeInfo,
      queryOptions: {
        cwd: queryOptions.cwd,
        model: queryOptions.model,
        effort: queryOptions.effort,
        resume: queryOptions.resume,
        pathToClaudeCodeExecutable: queryOptions.pathToClaudeCodeExecutable,
        settingSources: queryOptions.settingSources,
        permissionMode: queryOptions.permissionMode
      },
      env: {
        cwd: process.cwd(),
        ANTHROPIC_API_KEY_set: !!process.env.ANTHROPIC_API_KEY,
        nodeVersion: process.version
      }
    })

    try {
      // Capture the Query so interrupt() can call its native abort path.
      this._query = query({
        prompt: this._inputStream(null), // started without an initial prompt
        options: queryOptions
      })
      // Fetch AccountInfo once the query is up. The SDK exposes it via
      // a control-channel method (query.accountInfo()) — it does NOT
      // include `account` on the public SDKSystemMessage stream, despite
      // the type docs implying otherwise. Fire-and-forget; failures are
      // non-fatal (older SDKs without the method, agents on AWS/GCP
      // backends where the call has nothing to return, etc.).
      if (typeof this._query.accountInfo === 'function') {
        this._query.accountInfo().then(info => {
          if (info && this.manager?.updateAccountInfo) {
            this.manager.updateAccountInfo(info)
            this.emit({ sessionId: this.id, type: 'account_info', account: info })
          }
        }).catch(err => {
          this.log(`session ${this.id.slice(0, 8)} accountInfo() failed: ${err?.message || err}`)
        })
      }
      for await (const msg of this._query) {
        if (this.closed) break
        if (this.verbose) {
          const line = shortSdkSummary(msg)
          if (line) console.log(`[${this.id.slice(0, 8)}] ${line}`)
        }
        this._forward(msg)
      }
    } catch (err) {
      this.log(`session ${this.id} error: ${err.message || err}`)
      if (err && err.stack) this.log(`session ${this.id} stack: ${err.stack.split('\n').slice(0, 5).join(' | ')}`)
      this.emit({ sessionId: this.id, type: 'error', message: String(err.message || err) })
    } finally {
      // Skip close() during a settings-driven restart — we're tearing down
      // the old query() on purpose and a new _run() is about to start.
      // Emitting session_closed here would make the browser remove the
      // session from the active list mid-flight.
      if (!this.closed && !this._restarting) this.close('completed')
    }
  }

  // Translate one SDK message into one structured event for the server
  _forward(msg) {
    // Any message from the SDK (init, assistant text, tool_use, result…)
    // is real activity and should keep the session at the top of the
    // sidebar's "recent" sort. lastInputAt stays user-input-only so the
    // idle sweep's semantics ("user hasn't typed anything for N hours")
    // are preserved.
    this.lastActivityAt = Date.now()
    if (msg.type === 'system' && msg.subtype === 'init') {
      this.sdkSessionId = msg.session_id || null
      // A session created with "+ New Session" has no SDK id until this
      // init, so a title (or model/effort) set before its first answer was
      // saved under the agent's own id. list() reads the SDK id from here
      // on, which would make that title disappear — carry it over.
      if (this.sdkSessionId && this.sdkSessionId !== this.id && !this.resume) {
        const early = sessionSettings.load(this.id)
        if (early) {
          const merged = { ...early, ...(sessionSettings.load(this.sdkSessionId) || {}) }
          if (early.title && !merged.title) merged.title = early.title
          if (sessionSettings.save(this.sdkSessionId, merged)) sessionSettings.remove(this.id)
          this.log(`session ${this.id.slice(0, 8)} sidecar moved ${this.id.slice(0, 8)} → ${this.sdkSessionId.slice(0, 8)}`)
        }
      }
      // Surface the effort actually flowing into query(). The SDK's init
      // message doesn't echo back `effort`, so we resolve it ourselves
      // with the same priority order the runtime uses:
      //   per-session override → settings.json → SDK default ('high').
      // effortSource lets the UI tell where the value came from.
      let effort = this.effort
      let effortSource = effort ? 'session' : null
      if (!effort) {
        effort = readEffortPreference(this.folder)
        if (effort) effortSource = 'settings.json'
      }
      if (!effort) {
        effort = 'high'                  // SDK-documented default
        effortSource = 'sdk-default'
      }
      // The SDK ships AccountInfo (email, organization, plan, apiProvider)
      // on the init message of every session. Stash it on the manager so
      // the WhoAmI modal can read it without waiting for a fresh init.
      if (msg.account && this.manager) {
        this.manager.updateAccountInfo(msg.account)
      }
      this.emit({
        sessionId: this.id,
        type: 'init',
        sdkSessionId: this.sdkSessionId,
        model: msg.model || null,
        effort,
        effortSource,
        cwd: msg.cwd || null
      })
      return
    }
    if (msg.type === 'system' && msg.subtype === 'compact_boundary') {
      const m = msg.compact_metadata || {}
      this.emit({ sessionId: this.id, type: 'compact', preTokens: m.pre_tokens, postTokens: m.post_tokens, durationMs: m.duration_ms, trigger: m.trigger })
      return
    }
    // The model's safety classifier refused, and Claude Code either retried
    // on a fallback model (for the rest of the session, when scope is
    // 'session') or gave up. Used to be dropped with every other unknown
    // system subtype, so a session silently carried on with Opus 4.8 under
    // an "Opus 5.5" header and an init line that still read 5.5
    // (recruiting, 2026-10-07: category 'cyber', twice). Same event shape
    // as the replay path in session-store.js.
    if (msg.type === 'system' && (msg.subtype === 'model_refusal_fallback' || msg.subtype === 'model_refusal_no_fallback')) {
      this.emit({
        sessionId: this.id,
        type: 'model_fallback',
        fallback: msg.subtype === 'model_refusal_fallback',
        originalModel: msg.original_model || null,
        fallbackModel: msg.fallback_model || null,
        scope: msg.scope || (msg.subtype === 'model_refusal_fallback' ? 'session' : null),
        category: msg.api_refusal_category ?? null,
        explanation: msg.api_refusal_explanation ?? null,
        content: msg.content || null
      })
      return
    }
    // Subscription rate-limit telemetry. The SDK emits these for every
    // bucket (5h session, weekly all-models, weekly opus, weekly sonnet,
    // overage). Cache the latest per bucket on the SessionManager so the
    // WhoAmI modal can render the bars without waiting for fresh events.
    if (msg.type === 'rate_limit_event' && msg.rate_limit_info) {
      const info = msg.rate_limit_info
      if (this.manager) this.manager.updateRateLimit(info)
      this.emit({
        sessionId: this.id,
        type: 'rate_limit',
        rateLimitType: info.rateLimitType || null,
        utilization: typeof info.utilization === 'number' ? info.utilization : null,
        resetsAt: typeof info.resetsAt === 'number' ? info.resetsAt : null,
        status: info.status || null
      })
      return
    }
    // Forward status events ('requesting', 'awaiting_user', etc.) so the
    // browser can show a 'Sending request…' spinner during the gap between
    // user_input and the first content event arriving from the API.
    if (msg.type === 'system' && msg.subtype === 'status') {
      this.emit({ sessionId: this.id, type: 'status', status: msg.status || 'unknown' })
      return
    }
    // Partial / streaming events from the Anthropic API. When
    // includePartialMessages is enabled the SDK yields these between full
    // 'assistant' messages so the client can render text as it lands.
    if (msg.type === 'stream_event' && msg.event) {
      this._handleStreamEvent(msg.event)
      return
    }
    if (msg.type === 'assistant' && msg.message?.content) {
      const messageId = msg.message.id || null
      // If we already streamed this message's text/thinking via deltas,
      // skip emitting them again from the full message (browser is
      // already showing the streamed copy). Tool-use blocks aren't
      // streamed as text so we always emit those from the full message.
      const alreadyStreamed = !!messageId && this._streamedMessageIds.has(messageId)
      for (const block of msg.message.content) {
        if (block.type === 'text' && block.text) {
          if (alreadyStreamed) continue
          this.emit({ sessionId: this.id, type: 'assistant_text', text: block.text })
        } else if (block.type === 'thinking' && block.thinking) {
          if (alreadyStreamed) continue
          this.emit({ sessionId: this.id, type: 'thinking', text: block.thinking })
        } else if (block.type === 'tool_use') {
          this.pendingToolCount += 1
          this.emit({ sessionId: this.id, type: 'tool_use', tool: block.name, input: block.input, callId: block.id })
        }
      }
      return
    }
    if (msg.type === 'user' && Array.isArray(msg.message?.content)) {
      for (const block of msg.message.content) {
        if (block.type === 'tool_result') {
          if (this.pendingToolCount > 0) this.pendingToolCount -= 1
          const out = typeof block.content === 'string'
            ? block.content
            : Array.isArray(block.content) ? block.content.map(c => c.text || '').join('') : ''
          this.emit({ sessionId: this.id, type: 'tool_result', callId: block.tool_use_id, content: out, isError: !!block.is_error })
        }
      }
      return
    }
    if (msg.type === 'result') {
      // Forward modelUsage so the browser knows the model's exact
      // contextWindow + maxOutputTokens straight from the SDK — beats
      // guessing from the model name. Shape is { [modelId]: ModelUsage }.
      // Also persist it so the next session that resumes this transcript
      // gets the right contextWindow even though JSONL never stores it.
      modelWindows.recordModelUsage(msg.modelUsage)
      this.emit({
        sessionId: this.id,
        type: 'result',
        subtype: msg.subtype || null,
        usage: msg.usage || null,
        modelUsage: msg.modelUsage || null,
        costUsd: msg.total_cost_usd ?? null,
        // Window occupancy from the last message_start of this turn.
        // `usage` above stays cumulative — it is what the cost and token
        // totals are built from and they are correct — but it must not
        // be mistaken for a context measurement. null on the paths where
        // no streamed message arrived; the browser treats null as
        // "unknown" rather than guessing.
        contextTokens: this._lastContextTokens ?? null
      })
      return
    }
  }

  // Translate Anthropic stream events (when includePartialMessages is true)
  // into our delta events. Each text/thinking content block becomes a
  // sequence of assistant_text/thinking events sharing a streamId; the
  // browser merges them by streamId and renders the latest.
  _handleStreamEvent(ev) {
    if (!ev || typeof ev !== 'object') return
    switch (ev.type) {
      case 'message_start': {
        this._currentMessageId = ev.message?.id || null
        // How full the context window actually is.
        //
        // The `result` message's usage is CUMULATIVE across every API
        // call in the turn, so on a long tool-using turn its cache_read
        // alone reaches millions — the browser meter read 289% of a 1M
        // window off it. message_start carries the usage of THIS call,
        // and input + cache_read + cache_creation is precisely what was
        // sent to the model: the window's occupancy right now.
        //
        // Stored as the latest value, not a high-water mark: after a
        // compaction the window genuinely shrinks and a maximum would
        // never come back down.
        const u = ev.message?.usage
        if (u) {
          const snap = (u.input_tokens || 0)
            + (u.cache_read_input_tokens || 0)
            + (u.cache_creation_input_tokens || 0)
          if (snap > 0) this._lastContextTokens = snap
        }
        return
      }
      case 'content_block_start': {
        const idx = ev.index ?? 0
        const block = ev.content_block || {}
        if (block.type === 'text' || block.type === 'thinking') {
          const streamId = this._currentMessageId
            ? `${this._currentMessageId}:${block.type}:${idx}`
            : `local:${this.id}:${block.type}:${idx}:${Date.now()}`
          this._streamingText.set(idx, { kind: block.type, text: '', streamId })
          // Mark this message as streamed so the upcoming full assistant
          // yield doesn't duplicate the text. Marking on FIRST block_start
          // (not on stop) so even an empty stream is recognised.
          if (this._currentMessageId) this._streamedMessageIds.add(this._currentMessageId)
          // Emit an empty placeholder so the browser shows a row immediately.
          this.emit({
            sessionId: this.id,
            type: block.type === 'text' ? 'assistant_text' : 'thinking',
            text: '',
            streamId
          })
        }
        return
      }
      case 'content_block_delta': {
        const idx = ev.index ?? 0
        const slot = this._streamingText.get(idx)
        if (!slot) return
        const delta = ev.delta || {}
        if (delta.type === 'text_delta' && typeof delta.text === 'string') {
          slot.text += delta.text
          this.emit({ sessionId: this.id, type: 'assistant_text', text: slot.text, streamId: slot.streamId })
        } else if (delta.type === 'thinking_delta' && typeof delta.thinking === 'string') {
          slot.text += delta.thinking
          this.emit({ sessionId: this.id, type: 'thinking', text: slot.text, streamId: slot.streamId })
        }
        // input_json_delta for tool_use: ignore — we surface the final tool
        // input from the full assistant message instead.
        return
      }
      case 'content_block_stop': {
        const idx = ev.index ?? 0
        const slot = this._streamingText.get(idx)
        if (slot) {
          // Emit one final tick at the close of the block so the browser's
          // stream-merge fires its _endT stamp. Without this, a thinking
          // block that the model produced via signature-only / redacted
          // thinking (no thinking_delta events at all) leaves the browser
          // with the original empty placeholder and no end time, so
          // ThinkingGroup shows 'Thought for 0s'.
          const type = slot.kind === 'thinking' ? 'thinking' : 'assistant_text'
          this.emit({ sessionId: this.id, type, text: slot.text, streamId: slot.streamId })
          this._streamingText.delete(idx)
        }
        return
      }
      case 'message_stop':
        return
    }
  }
}

// Auto-close policy: bounded resources without user housekeeping.
const IDLE_TIMEOUT_MS = 4 * 60 * 60 * 1000   // 4h with no user input → auto-close
const MAX_CONCURRENT_SESSIONS = 8         // hard cap; LRU-evict oldest-idle
const IDLE_SWEEP_INTERVAL_MS = 60 * 1000  // check once a minute

class SessionManager {
  constructor({ emit, log, config, verbose }) {
    this.emit = emit
    this.log = log
    this.config = config  // shared agent config — used for persisted permissions
    this.verbose = !!verbose
    this.sessions = new Map()
    // Account info + per-bucket rate-limit info, populated as sessions
    // emit init / rate_limit_event messages. The values persist across
    // session lifetimes so the WhoAmI modal renders even when no
    // session is currently running.
    this.accountInfo = null
    this.rateLimits = {}     // keyed by rateLimitType: 'five_hour' | 'seven_day' | …
    this._idleSweep = setInterval(() => this._sweepIdle(), IDLE_SWEEP_INTERVAL_MS)
  }

  updateAccountInfo(account) {
    if (!account || typeof account !== 'object') return
    // In proxy mode the SDK reports `apiProvider: 'firstParty'` (because
    // it IS talking to api.anthropic.com — just via our server) but
    // every user-identity field is null because the upstream auth is
    // an org-level API key. Showing "Claude AI" + dashes is misleading;
    // override with a synthetic proxy AccountInfo so the WhoAmI modal
    // can render correctly and the per-row "—" is suppressed.
    const inProxyMode = !!process.env.ANTHROPIC_BASE_URL
      && process.env.ANTHROPIC_API_KEY === this.config?.mineToken
    if (inProxyMode) {
      account = {
        ...account,
        apiProvider: 'proxy',
        proxyUrl: process.env.ANTHROPIC_BASE_URL,
        serverUrl: this.config?.serverUrl || null,
        forceProxy: !!this.config?.forceProxy
      }
    }
    // Shallow-merge so a later init that omits a field doesn't clobber it.
    const before = this.accountInfo
    this.accountInfo = { ...(this.accountInfo || {}), ...account, fetchedAt: Date.now() }
    // Echo to the agent terminal the FIRST time we learn the account
    // identity — useful confirmation that you're talking to claude.ai
    // as the right person on a shared / remote box. Suppressed on
    // updates to avoid spamming on every session start.
    const learned = !before || (
      before.email !== this.accountInfo.email
      || before.organization !== this.accountInfo.organization
      || before.subscriptionType !== this.accountInfo.subscriptionType
      || before.apiProvider !== this.accountInfo.apiProvider
    )
    if (learned) {
      const a = this.accountInfo
      const provider =
        a.apiProvider === 'firstParty' ? 'Claude AI'
        : a.apiProvider === 'bedrock'  ? 'AWS Bedrock'
        : a.apiProvider === 'vertex'   ? 'Google Vertex'
        : a.apiProvider === 'foundry'  ? 'Azure AI Foundry'
        : (a.apiKeySource ? `API key (${a.apiKeySource})` : (a.apiProvider || 'unknown'))
      const plan = a.subscriptionType
        ? a.subscriptionType.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase())
        : null
      const parts = [provider]
      if (a.email) parts.push(a.email)
      if (a.organization) parts.push(a.organization)
      if (plan) parts.push(`plan: ${plan}`)
      console.log(`[account] ${parts.join(' · ')}`)
    }
  }

  updateRateLimit(info) {
    if (!info || !info.rateLimitType) return
    this.rateLimits[info.rateLimitType] = {
      ...info,
      fetchedAt: Date.now()
    }
  }

  /** Snapshot for the /account-usage endpoint. Returns whatever has been
   *  observed so far — empty object on a fresh agent that's never run a
   *  session. The browser shows '—' for missing buckets. */
  getAccountUsage() {
    return {
      account: this.accountInfo || null,
      rateLimits: this.rateLimits || {}
    }
  }

  _sweepIdle() {
    const now = Date.now()
    for (const s of this.sessions.values()) {
      if (s.closed) continue
      if (s.pendingToolCount > 0) continue  // mid-tool — leave alone
      const idleMs = now - s.lastInputAt
      if (idleMs > IDLE_TIMEOUT_MS) {
        console.log(`[session-manager] idle-closing ${s.id.slice(0, 8)}… (${Math.round(idleMs / 60000)}min idle, name="${s.name}")`)
        s.close('idle_timeout')
      }
    }
  }

  // Drop the least-recently-used non-tool-pending session so a new one fits
  // under MAX_CONCURRENT_SESSIONS. Sessions with pending tool work are
  // preserved (closing them mid-tool would orphan a Bash etc).
  _evictForCapacity() {
    const candidates = Array.from(this.sessions.values())
      .filter(s => !s.closed && s.pendingToolCount === 0)
    if (candidates.length < MAX_CONCURRENT_SESSIONS) return
    candidates.sort((a, b) => a.lastInputAt - b.lastInputAt)
    const victim = candidates[0]
    console.log(`[session-manager] LRU-evicting ${victim.id.slice(0, 8)}… to stay under ${MAX_CONCURRENT_SESSIONS} (name="${victim.name}")`)
    victim.close('lru_evicted')
    this.sessions.delete(victim.id)
  }

  // ----- shared permission state -----

  isAlwaysAllowed(toolName) {
    return Array.isArray(this.config?.alwaysAllowedTools)
      && this.config.alwaysAllowedTools.includes(toolName)
  }

  addAlwaysAllowed(toolName) {
    if (!this.config) return
    if (!Array.isArray(this.config.alwaysAllowedTools)) this.config.alwaysAllowedTools = []
    if (!this.config.alwaysAllowedTools.includes(toolName)) {
      this.config.alwaysAllowedTools.push(toolName)
      saveConfig(this.config)
    }
  }

  list() {
    return Array.from(this.sessions.values()).map(s => {
      // Pull parentSessionId from the sidecar so the sidebar can nest
      // forks under their root parent. We deliberately key the sidecar
      // by sdkSessionId (not the in-memory id) so resumed sessions
      // pick the same fork-tree position as last time.
      const sdkKey = s.sdkSessionId || s.resume || s.id
      const sidecar = sdkKey ? (sessionSettings.load(sdkKey) || {}) : {}
      return ({
      id: s.id,
      name: s.name,
      // User-supplied title from the sidebar's pencil icon — overrides
      // `name` for display. Falls back to the in-memory s.title (kept
      // in sync by applyTitle), and finally to the sidecar's title
      // when the in-memory copy was never set (defensive — should
      // already match because the constructor reads from sidecar).
      // Straight from the sidecar on every call — never the in-memory
      // copy. See applyTitle.
      title: (typeof sidecar.title === 'string' && sidecar.title) ? sidecar.title : null,
      folder: s.folder,
      sdkSessionId: s.sdkSessionId,
      resume: s.resume,
      startedAt: s.startedAt,
      lastActivityAt: s.lastActivityAt || s.startedAt,
      running: !s.closed,
      parentSessionId: sidecar.parentSessionId || null,
      // Snapshot of the parent's totals at the moment THIS session was
      // forked. Browser subtracts it from the running cumulative so
      // the cost / token meter shows only this session's own spend
      // (without it, a fork would inflate by the inherited prefix the
      // SDK physically copied into its JSONL). null for non-forks AND
      // for legacy forks created before 0.3.38 — UI shows '—' in that
      // case rather than a misleading number.
      forkBaseline: sidecar.forkBaseline || null,
      // Settings popover state. `model` and `effort` are the user's
      // *explicit* per-session override (null = "no override"). The
      // *effective* values factor in ~/.claude/settings.json's defaults
      // — those are what's really flowing into query(), so the popover
      // should highlight them.
      model: s.model,
      effort: s.effort,
      effectiveEffort: s.effort || readEffortPreference(s.folder) || null,
      pendingRestart: !!s._pendingRestart
    })
    })
  }

  get(id) { return this.sessions.get(id) }

  /** Find an existing session in `folder` that's still empty — i.e. the
   *  user never sent a first message and it's not a resume of a past
   *  transcript. Returns the session id if one exists, else null.
   *
   *  Used by the create-session handler to be idempotent against
   *  "+ New Session" multi-clicks: rather than spawning a fresh active
   *  session each time, we hand back the dangling one. The caller
   *  decides whether to apply the new request's `name` to the existing
   *  session (we leave that policy to uplink.js).
   *
   *  Excluded:
   *    - closed sessions (already torn down)
   *    - sessions in a different folder
   *    - resumed sessions (s.resume set — those map to a real JSONL)
   *    - sessions with first user input (s._hasUserInput) */
  findIdleEmpty(folder) {
    if (!folder) return null
    for (const s of this.sessions.values()) {
      if (s.closed) continue
      if (s.folder !== folder) continue
      if (s.resume) continue
      if (s._hasUserInput) continue
      return s.id
    }
    return null
  }

  create({ id, name, folder, model, effort, resume, sessionEnv }) {
    if (this.sessions.has(id)) return { error: 'session_exists' }
    this._evictForCapacity()
    const s = new Session({
      id, name, folder, model, effort, resume,
      sessionEnv,
      emit: this.emit, log: this.log, manager: this, verbose: this.verbose
    })
    this.sessions.set(id, s)
    return s
  }

  delete(id) {
    const s = this.sessions.get(id)
    if (!s) return false
    s.close('deleted')
    this.sessions.delete(id)
    return true
  }

  // Rename: store a user-supplied display title in the per-session sidecar.
  // Works for both active sessions (live applyTitle) and past JSONL-only
  // sessions (sidecar write only — no in-memory state to update).
  // `id` may be the agent's internal Session.id OR the SDK session id;
  // we resolve which by checking the active map first.
  rename(id, title) {
    const s = this.sessions.get(id)
    if (s) {
      const r = s.applyTitle(title)
      if (!r.ok) return { ok: false, error: `title was not saved (${r.error})`, sdkSessionId: r.key }
      return { ok: true, changed: true, sdkSessionId: r.key, title: r.title }
    }
    // Past session — id is the SDK transcript filename. Refuse to write a
    // sidecar for an id that has no JSONL on disk so we don't leak orphan
    // sidecars from typos / replay attacks.
    const sessionStore = require('./session-store')
    const file = sessionStore.findTranscript(id)
    if (!file) return { ok: false, error: 'session not found' }
    const next = (typeof title === 'string' && title.trim()) ? title.trim().slice(0, 200) : null
    const written = writeTitleVerified(id, next)
    this.log?.(`[rename] past ${id.slice(0, 8)} title ${written.ok ? 'saved' : 'NOT SAVED'} title=${JSON.stringify(next)}${written.error ? ' error=' + written.error : ''}`)
    if (!written.ok) return { ok: false, error: `title was not saved (${written.error})`, sdkSessionId: id }
    return { ok: true, changed: true, sdkSessionId: id, title: next }
  }

  // Hard-delete a session: close any in-memory query, unlink the SDK's
  // JSONL transcript, and remove the sidecar. Forks (children whose
  // sidecar.parentSessionId points at this session's SDK id) are NOT
  // cascaded — they survive as orphans (their JSONL is intact, they'll
  // appear at the root level of the sidebar).
  // `id` may be the agent's internal Session.id OR the SDK session id.
  purge(id) {
    let sdkId = id
    const s = this.sessions.get(id)
    if (s) {
      sdkId = s.sdkSessionId || s.resume || s.id
      s.close('purged')
      this.sessions.delete(id)
    }
    const sessionStore = require('./session-store')
    const file = sessionStore.findTranscript(sdkId)
    let removedFile = false
    if (file) {
      try {
        fs.unlinkSync(file)
        removedFile = true
      } catch (err) {
        this.log?.(`[purge] failed to unlink ${file}: ${err.message}`)
      }
    }
    sessionSettings.remove(sdkId)
    this.log?.(`[purge] session ${id.slice(0, 8)} removedFile=${removedFile} sdkId=${sdkId.slice(0, 8)}`)
    return { ok: true, removedFile, sdkSessionId: sdkId }
  }

  closeAll() {
    if (this._idleSweep) { clearInterval(this._idleSweep); this._idleSweep = null }
    for (const s of this.sessions.values()) s.close('shutdown')
    this.sessions.clear()
  }
}

module.exports = { SessionManager, claudeExeInfo }
