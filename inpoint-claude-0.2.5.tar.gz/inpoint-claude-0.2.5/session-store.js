// session-store.js
// Read past sessions from the location Claude Agent SDK uses:
//   ~/.claude/projects/<encoded-cwd>/<sessionId>.jsonl
// Each JSONL line contains a structured message — the first 'user' line
// is typically the first prompt; the file mtime gives recency.

const fs = require('node:fs')
const path = require('node:path')
const os = require('node:os')

const ROOT = path.join(os.homedir(), '.claude', 'projects')

// Decode the SDK's project folder name.
// Claude encodes a path by replacing '/' with '-' and stripping leading slash;
// e.g. /Users/ilya/work → -Users-ilya-work. This isn't a perfect inverse, so
// we surface what we can find rather than trying to reconstruct the original.
function decodeProjectDir(name) {
  // For display only — best-effort
  return name.replace(/^-/, '/').replace(/-/g, '/')
}

function listProjects() {
  try {
    const entries = fs.readdirSync(ROOT, { withFileTypes: true })
    return entries
      .filter(e => e.isDirectory())
      .map(e => ({
        dir: path.join(ROOT, e.name),
        encodedName: e.name,
        displayPath: decodeProjectDir(e.name)
      }))
  } catch { return [] }
}

function listSessionsInProject(projectDir, limit = 50) {
  try {
    const files = fs.readdirSync(projectDir)
      .filter(f => f.endsWith('.jsonl'))
      .map(f => {
        const full = path.join(projectDir, f)
        let mtime = 0, size = 0
        try { const st = fs.statSync(full); mtime = st.mtimeMs; size = st.size } catch {}
        return { sessionId: f.replace(/\.jsonl$/, ''), file: full, mtime, size }
      })
      .sort((a, b) => b.mtime - a.mtime)
      .slice(0, limit)

    // Read the first lines of each transcript to grab the original cwd
    // (from system/init) and a first-prompt label.
    return files.map(f => {
      let firstPrompt = null
      let cwd = null
      try {
        const head = fs.readFileSync(f.file, 'utf8').slice(0, 16 * 1024)
        for (const line of head.split('\n')) {
          if (!line) continue
          try {
            const obj = JSON.parse(line)
            if (!cwd && typeof obj.cwd === 'string') cwd = obj.cwd
            if (!firstPrompt && obj.type === 'user' && obj.message?.role === 'user') {
              const c = obj.message.content
              if (typeof c === 'string') firstPrompt = c.slice(0, 120)
              else if (Array.isArray(c)) {
                const t = c.find(x => x.type === 'text')?.text
                if (t) firstPrompt = String(t).slice(0, 120)
              }
            }
            if (cwd && firstPrompt) break
          } catch { /* skip malformed line */ }
        }
      } catch {}
      return { ...f, firstPrompt, cwd }
    })
  } catch { return [] }
}

function listAll(limitPerProject = 20) {
  const projects = listProjects()
  const out = []
  for (const p of projects) {
    for (const s of listSessionsInProject(p.dir, limitPerProject)) {
      out.push({ ...s, project: p.encodedName, projectDisplay: p.displayPath })
    }
  }
  return out.sort((a, b) => b.mtime - a.mtime)
}

/**
 * Locate the SDK's JSONL transcript for a session id by scanning every
 * project directory. We don't know which project a session belongs to
 * until we look — projects are encoded-cwd directories.
 */
function findTranscript(sessionId) {
  try {
    for (const e of fs.readdirSync(ROOT, { withFileTypes: true })) {
      if (!e.isDirectory()) continue
      const candidate = path.join(ROOT, e.name, `${sessionId}.jsonl`)
      if (fs.existsSync(candidate)) return candidate
    }
  } catch {}
  return null
}

/**
 * Read a transcript and translate each SDK message into the same
 * structured-event shape the agent emits live, so the browser can
 * replay history without a separate format. Returns at most `limit`
 * events from the END of the file.
 */
function readSessionEvents(sessionId, limit = 100) {
  const file = findTranscript(sessionId)
  if (!file) return []
  let raw = ''
  try { raw = fs.readFileSync(file, 'utf8') } catch { return [] }
  const events = []
  for (const line of raw.split('\n')) {
    if (!line) continue
    let msg
    try { msg = JSON.parse(line) } catch { continue }
    pushEventsFromMessage(events, sessionId, msg)
  }
  return events.slice(-limit)
}

// Mirrors session-manager.js _forward — keep these two in sync if the
// SDK's message shape evolves.
function pushEventsFromMessage(events, sessionId, msg) {
  if (msg.type === 'system' && msg.subtype === 'init') {
    events.push({
      sessionId,
      type: 'init',
      sdkSessionId: msg.session_id || null,
      model: msg.model || null,
      cwd: msg.cwd || null
    })
    return
  }
  if (msg.type === 'system' && msg.subtype === 'compact_boundary') {
    const m = msg.compact_metadata || {}
    events.push({
      sessionId, type: 'compact',
      preTokens: m.pre_tokens, postTokens: m.post_tokens,
      durationMs: m.duration_ms, trigger: m.trigger
    })
    return
  }
  if (msg.type === 'assistant' && msg.message?.content) {
    for (const block of msg.message.content) {
      if (block.type === 'text' && block.text) {
        events.push({ sessionId, type: 'assistant_text', text: block.text })
      } else if (block.type === 'thinking' && block.thinking) {
        events.push({ sessionId, type: 'thinking', text: block.thinking })
      } else if (block.type === 'tool_use') {
        events.push({ sessionId, type: 'tool_use', tool: block.name, input: block.input, callId: block.id })
      }
    }
    return
  }
  if (msg.type === 'user' && Array.isArray(msg.message?.content)) {
    for (const block of msg.message.content) {
      if (block.type === 'tool_result') {
        const out = typeof block.content === 'string'
          ? block.content
          : Array.isArray(block.content) ? block.content.map(c => c.text || '').join('') : ''
        events.push({ sessionId, type: 'tool_result', callId: block.tool_use_id, content: out, isError: !!block.is_error })
      } else if (block.type === 'text' && block.text) {
        events.push({ sessionId, type: 'user_input', text: block.text })
      }
    }
    // SDK also stores plain string user prompts as message.content === string
    if (typeof msg.message.content === 'string' && msg.message.content) {
      events.push({ sessionId, type: 'user_input', text: msg.message.content })
    }
    return
  }
  if (msg.type === 'user' && typeof msg.message?.content === 'string') {
    events.push({ sessionId, type: 'user_input', text: msg.message.content })
    return
  }
  if (msg.type === 'result') {
    events.push({
      sessionId, type: 'result',
      subtype: msg.subtype || null,
      usage: msg.usage || null,
      costUsd: msg.total_cost_usd ?? null
    })
  }
}

module.exports = { listProjects, listSessionsInProject, listAll, ROOT, findTranscript, readSessionEvents }
