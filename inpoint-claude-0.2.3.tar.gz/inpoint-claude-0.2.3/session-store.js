// session-store.js
// Read past sessions from the location Claude Agent SDK uses:
//   ~/.claude/projects/<encoded-cwd>/<sessionId>.jsonl
// Each JSONL line contains a structured message — the first 'user' line
// is typically the first prompt; the file mtime gives recency.

const fs = require('node:fs')
const path = require('node:path')
const os = require('node:os')

const ROOT = path.join(os.homedir(), '.claude', 'projects')

// Decode the SDK's project folder name.
// Claude encodes a path by replacing '/' with '-' and stripping leading slash;
// e.g. /Users/ilya/work → -Users-ilya-work. This isn't a perfect inverse, so
// we surface what we can find rather than trying to reconstruct the original.
function decodeProjectDir(name) {
  // For display only — best-effort
  return name.replace(/^-/, '/').replace(/-/g, '/')
}

function listProjects() {
  try {
    const entries = fs.readdirSync(ROOT, { withFileTypes: true })
    return entries
      .filter(e => e.isDirectory())
      .map(e => ({
        dir: path.join(ROOT, e.name),
        encodedName: e.name,
        displayPath: decodeProjectDir(e.name)
      }))
  } catch { return [] }
}

function listSessionsInProject(projectDir, limit = 50) {
  try {
    const files = fs.readdirSync(projectDir)
      .filter(f => f.endsWith('.jsonl'))
      .map(f => {
        const full = path.join(projectDir, f)
        let mtime = 0, size = 0
        try { const st = fs.statSync(full); mtime = st.mtimeMs; size = st.size } catch {}
        return { sessionId: f.replace(/\.jsonl$/, ''), file: full, mtime, size }
      })
      .sort((a, b) => b.mtime - a.mtime)
      .slice(0, limit)

    // Read the first lines of each transcript to grab the original cwd
    // (from system/init) and a first-prompt label.
    return files.map(f => {
      let firstPrompt = null
      let cwd = null
      try {
        const head = fs.readFileSync(f.file, 'utf8').slice(0, 16 * 1024)
        for (const line of head.split('\n')) {
          if (!line) continue
          try {
            const obj = JSON.parse(line)
            if (!cwd && typeof obj.cwd === 'string') cwd = obj.cwd
            if (!firstPrompt && obj.type === 'user' && obj.message?.role === 'user') {
              const c = obj.message.content
              if (typeof c === 'string') firstPrompt = c.slice(0, 120)
              else if (Array.isArray(c)) {
                const t = c.find(x => x.type === 'text')?.text
                if (t) firstPrompt = String(t).slice(0, 120)
              }
            }
            if (cwd && firstPrompt) break
          } catch { /* skip malformed line */ }
        }
      } catch {}
      return { ...f, firstPrompt, cwd }
    })
  } catch { return [] }
}

function listAll(limitPerProject = 20) {
  const projects = listProjects()
  const out = []
  for (const p of projects) {
    for (const s of listSessionsInProject(p.dir, limitPerProject)) {
      out.push({ ...s, project: p.encodedName, projectDisplay: p.displayPath })
    }
  }
  return out.sort((a, b) => b.mtime - a.mtime)
}

module.exports = { listProjects, listSessionsInProject, listAll, ROOT }
