// Claude Terminal Proxy — agent process.
// Connects to an etra-ai server and runs Claude Agent SDK sessions on demand.

// Prefix every stdout / stderr line with HH:MM:SS so the agent's terminal
// reads chronologically. Lines that already start with '#NNNN' (per-event
// numbered traces from uplink.js) skip the prefix — those format their
// own timestamp inline so the number stays at the very left for grouping.
;(() => {
  const _log = console.log
  const _err = console.error
  const ts = () => {
    const d = new Date()
    const p = n => String(n).padStart(2, '0')
    return `${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`
  }
  const wrap = (orig) => (...args) => {
    const first = args[0]
    if (typeof first === 'string' && /^#\d{4}\b/.test(first)) {
      orig(...args)
    } else if (typeof first === 'string') {
      orig(`${ts()} ${first}`, ...args.slice(1))
    } else {
      orig(ts(), ...args)
    }
  }
  console.log = wrap(_log)
  console.error = wrap(_err)
})()

const { loadConfig, saveConfig } = require('./config')
const { createUplink } = require('./uplink')
const { SessionManager } = require('./session-manager')
const sessionStore = require('./session-store')
const { takeLock } = require('./single-instance')

function parseArgs(args) {
  const opts = { server: null, apiKey: null, showToken: false, verbose: false }
  for (let i = 0; i < args.length; i++) {
    switch (args[i]) {
      case '--server': opts.server = args[++i]; break
      case '--api-key': opts.apiKey = args[++i]; break
      case '--token': opts.showToken = true; break
      case '-v':
      case '--verbose': opts.verbose = true; break
      case '--help': printUsage(); process.exit(0)
    }
  }
  return opts
}

function loadDotEnv() {
  const fs = require('fs')
  const path = require('path')
  const envPath = path.join(process.cwd(), '.env')
  if (!fs.existsSync(envPath)) return
  try {
    for (const line of fs.readFileSync(envPath, 'utf-8').split('\n')) {
      const trimmed = line.trim()
      if (!trimmed || trimmed.startsWith('#')) continue
      const m = trimmed.match(/^(?:export\s+)?([^=]+)=(.*)$/)
      if (!m) continue
      const key = m[1].trim()
      let value = m[2].trim()
      if ((value.startsWith('"') && value.endsWith('"')) ||
          (value.startsWith("'") && value.endsWith("'"))) {
        value = value.slice(1, -1)
      }
      if (!process.env[key]) process.env[key] = value
    }
  } catch { /* ignore */ }
}

function printUsage() {
  console.log(`
Claude Terminal Proxy — Claude Agent SDK bridge

Usage:
  node index.js --server <url>

Options:
  --server <url>      Server URL to connect to (e.g., https://ai.inpoint.dev)
                      Saved in config after first use.
  --api-key <key>     Optional ANTHROPIC_API_KEY fallback. If absent, the SDK
                      uses your claude.ai OAuth login from the OS keychain.
  --token             Print this agent's share token and exit.
  -v, --verbose       Log every message received from the Claude Agent SDK
                      to stdout. Useful for debugging streaming, tool use,
                      and permission round-trips.
  --help              Show this message

Agent config is stored in ~/.claude-terminal-proxy/agent.json
Past Claude sessions are read from ~/.claude/projects/
`)
}

const opts = parseArgs(process.argv.slice(2))
loadDotEnv()
const config = loadConfig()

if (opts.showToken) {
  console.log(config.shareToken)
  process.exit(0)
}

// Show help only when there's nothing to run — no args AND no saved server URL.
if (process.argv.length <= 2 && !config.serverUrl) {
  printUsage()
  process.exit(0)
}

if (opts.server) { config.serverUrl = opts.server; saveConfig(config) }
if (opts.apiKey) { config.defaultApiKey = opts.apiKey; saveConfig(config) }

const serverUrl = config.serverUrl || null
const envApiKey = process.env.ANTHROPIC_API_KEY
const effectiveDefaultKey = config.defaultApiKey || envApiKey

console.log(`Claude Terminal Proxy`)
console.log(`  Name:        ${config.name}`)
console.log(`  Server:      ${serverUrl || '(not configured)'}`)
console.log(`  Mine token:  ${config.mineToken.slice(0, 15)}... (private — do not share)`)
console.log(`  Share token: ${config.shareToken}`)
console.log(`               ↑ paste into "Paste agent token…" at ${(serverUrl || 'https://ai.inpoint.dev').replace(/\/$/, '')}/claude`)
console.log(`  Auth:        ${effectiveDefaultKey ? 'API key (' + effectiveDefaultKey.slice(0, 12) + '...)' : 'OAuth keychain (claude /login)'}`)
console.log()

if (!serverUrl) {
  console.error('Error: No server URL configured. Use --server <url>')
  process.exit(1)
}

// Singleton: kill any prior inpoint-claude that's still running on this
// machine. Two heartbeating with the same mineToken makes the server's
// SSE channel flap, which the user notices as "the chat keeps dropping
// out". Call only after we've decided to actually run — --token /
// --help / --show-token paths above already exited.
takeLock()

// If a default API key is configured, expose it to the SDK via env.
if (config.defaultApiKey && !process.env.ANTHROPIC_API_KEY) {
  process.env.ANTHROPIC_API_KEY = config.defaultApiKey
}

// Two-phase wiring: SessionManager needs an emit callback, but the uplink
// needs SessionManager to dispatch commands. Build uplink with a forwarder
// closure that resolves to SessionManager once it exists.
let sessionManager = null
const sessionManagerRef = {
  create: (...a) => sessionManager.create(...a),
  delete: (...a) => sessionManager.delete(...a),
  list: (...a) => sessionManager.list(...a),
  get: (...a) => sessionManager.get(...a)
}

const uplink = createUplink(serverUrl, config, sessionManagerRef, sessionStore)
sessionManager = new SessionManager({
  emit: (event) => uplink.emit(event),
  log: (msg) => console.log(`[session] ${msg}`),
  config,
  verbose: opts.verbose
})

uplink.start()

function shutdown() {
  console.log('\nShutting down...')
  uplink.stop()
  sessionManager.closeAll()
  process.exit(0)
}
process.on('SIGINT', shutdown)
process.on('SIGTERM', shutdown)
