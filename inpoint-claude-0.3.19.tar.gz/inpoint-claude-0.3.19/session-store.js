// session-store.js
// Read past sessions from the location Claude Agent SDK uses:
//   ~/.claude/projects/<encoded-cwd>/<sessionId>.jsonl
// Each JSONL line contains a structured message — the first 'user' line
// is typically the first prompt; the file mtime gives recency.

const fs = require('node:fs')
const path = require('node:path')
const os = require('node:os')
const modelWindows = require('./model-windows')

const ROOT = path.join(os.homedir(), '.claude', 'projects')

// Decode the SDK's project folder name.
// Claude encodes a path by replacing '/' with '-' and stripping leading slash;
// e.g. /Users/ilya/work → -Users-ilya-work. This isn't a perfect inverse, so
// we surface what we can find rather than trying to reconstruct the original.
function decodeProjectDir(name) {
  // For display only — best-effort
  return name.replace(/^-/, '/').replace(/-/g, '/')
}

function listProjects() {
  try {
    const entries = fs.readdirSync(ROOT, { withFileTypes: true })
    return entries
      .filter(e => e.isDirectory())
      .map(e => ({
        dir: path.join(ROOT, e.name),
        encodedName: e.name,
        displayPath: decodeProjectDir(e.name)
      }))
  } catch { return [] }
}

function listSessionsInProject(projectDir, limit = 50) {
  try {
    const files = fs.readdirSync(projectDir)
      .filter(f => f.endsWith('.jsonl'))
      .map(f => {
        const full = path.join(projectDir, f)
        let mtime = 0, size = 0
        try { const st = fs.statSync(full); mtime = st.mtimeMs; size = st.size } catch {}
        return { sessionId: f.replace(/\.jsonl$/, ''), file: full, mtime, size }
      })
      .sort((a, b) => b.mtime - a.mtime)
      .slice(0, limit)

    // Read the first lines of each transcript to grab the original cwd
    // (from system/init) and a first-prompt label.
    return files.map(f => {
      let firstPrompt = null
      let cwd = null
      try {
        const head = fs.readFileSync(f.file, 'utf8').slice(0, 16 * 1024)
        for (const line of head.split('\n')) {
          if (!line) continue
          try {
            const obj = JSON.parse(line)
            if (!cwd && typeof obj.cwd === 'string') cwd = obj.cwd
            if (!firstPrompt && obj.type === 'user' && obj.message?.role === 'user') {
              const c = obj.message.content
              if (typeof c === 'string') firstPrompt = c.slice(0, 120)
              else if (Array.isArray(c)) {
                const t = c.find(x => x.type === 'text')?.text
                if (t) firstPrompt = String(t).slice(0, 120)
              }
            }
            if (cwd && firstPrompt) break
          } catch { /* skip malformed line */ }
        }
      } catch {}
      return { ...f, firstPrompt, cwd }
    })
  } catch { return [] }
}

function listAll(limitPerProject = 20) {
  const projects = listProjects()
  const out = []
  for (const p of projects) {
    for (const s of listSessionsInProject(p.dir, limitPerProject)) {
      // Skip sessions whose JSONL transcript didn't record a real cwd —
      // we can't show them under a folder-grouped UI anyway.
      if (!s.cwd) continue
      out.push({ ...s, project: p.encodedName, projectDisplay: p.displayPath })
    }
  }
  return out.sort((a, b) => b.mtime - a.mtime)
}

/**
 * Locate the SDK's JSONL transcript for a session id by scanning every
 * project directory. We don't know which project a session belongs to
 * until we look — projects are encoded-cwd directories.
 */
function findTranscript(sessionId) {
  try {
    for (const e of fs.readdirSync(ROOT, { withFileTypes: true })) {
      if (!e.isDirectory()) continue
      const candidate = path.join(ROOT, e.name, `${sessionId}.jsonl`)
      if (fs.existsSync(candidate)) return candidate
    }
  } catch {}
  return null
}

/**
 * Read a transcript and translate each SDK message into our structured
 * event shape. Returns a window of at most `limit` events, but extends
 * the start backward (up to MAX_EXTRA more events) so it always begins
 * at a `user_input` event — this way every loaded chunk reads as a
 * complete question + everything that followed.
 *
 * Pagination: pass `beforeIndex` (received from a previous call's
 * `startIndex`) to load the chunk preceding what's already on screen.
 *
 * Returns: { events, totalCount, startIndex, endIndex }
 *   - totalCount: total events in the JSONL right now
 *   - startIndex / endIndex: half-open range describing this slice
 *     (0 ≤ startIndex < endIndex ≤ totalCount). When startIndex > 0
 *     the caller knows there's earlier history to fetch.
 *
 * The very first `init` event (with the model + cwd) is always
 * prepended when not already in the slice so the browser's context
 * meter never falls back to a 200k guess.
 */
function readSessionEvents(sessionId, opts = {}) {
  const { limit = 100, beforeIndex } = typeof opts === 'object' ? opts : { limit: opts }
  const file = findTranscript(sessionId)
  if (!file) return { events: [], totalCount: 0, startIndex: 0, endIndex: 0 }
  let raw = ''
  try { raw = fs.readFileSync(file, 'utf8') } catch { return { events: [], totalCount: 0, startIndex: 0, endIndex: 0 } }
  const all = []
  // Track the previous message's timestamp so thinking blocks can be
  // assigned a non-zero `[_t, _endT]` span — JSONL only has one timestamp
  // per message, so individual blocks within a message all collapse to
  // the same instant. The gap from prev-message to this-message ≈ the
  // wall-clock time spent thinking before the current message landed.
  let prevMessageT = null
  for (const line of raw.split('\n')) {
    if (!line) continue
    let msg
    try { msg = JSON.parse(line) } catch { continue }
    pushEventsFromMessage(all, sessionId, msg, prevMessageT)
    const t = msg.timestamp ? Date.parse(msg.timestamp) : NaN
    if (Number.isFinite(t)) prevMessageT = t
  }
  const totalCount = all.length
  if (totalCount === 0) return { events: [], totalCount, startIndex: 0, endIndex: 0 }

  const endIdx = (typeof beforeIndex === 'number')
    ? Math.max(0, Math.min(beforeIndex, totalCount))
    : totalCount
  let startIdx = Math.max(0, endIdx - limit)
  // Extend the start backward to the nearest user_input so the chunk
  // begins with a question. Cap the extension to keep absurd-tool-run
  // cases bounded.
  const MAX_EXTRA = 500
  let extra = 0
  while (startIdx > 0 && extra < MAX_EXTRA && all[startIdx].type !== 'user_input') {
    startIdx--
    extra++
  }

  const slice = all.slice(startIdx, endIdx)
  // Total user_input events in the whole JSONL — used by the browser's
  // 'X of Y questions' counter at the top of the chat.
  const totalQuestions = all.reduce((n, e) => n + (e.type === 'user_input' ? 1 : 0), 0)
  // Always make sure the browser sees the first init event so it knows
  // the model. If our slice started later, prepend a copy.
  if (startIdx > 0) {
    const firstInit = all.find(e => e.type === 'init')
    if (firstInit && !slice.includes(firstInit)) {
      return { events: [firstInit, ...slice], totalCount, totalQuestions, startIndex: startIdx, endIndex: endIdx }
    }
  }
  return { events: slice, totalCount, totalQuestions, startIndex: startIdx, endIndex: endIdx }
}

// Mirrors session-manager.js _forward — keep these two in sync if the
// SDK's message shape evolves. Each emitted event carries `_t` (the SDK
// timestamp from the JSONL) so the UI can compute real durations for
// replayed thinking groups.
function pushEventsFromMessage(events, sessionId, msg, prevMessageT) {
  const _t = msg.timestamp ? Date.parse(msg.timestamp) || undefined : undefined
  const stamp = (e) => (_t ? { ...e, _t } : e)

  if (msg.type === 'system' && msg.subtype === 'init') {
    events.push(stamp({
      sessionId,
      type: 'init',
      sdkSessionId: msg.session_id || null,
      model: msg.model || null,
      cwd: msg.cwd || null
    }))
    return
  }
  if (msg.type === 'system' && msg.subtype === 'compact_boundary') {
    const m = msg.compact_metadata || {}
    events.push(stamp({
      sessionId, type: 'compact',
      preTokens: m.pre_tokens, postTokens: m.post_tokens,
      durationMs: m.duration_ms, trigger: m.trigger
    }))
    return
  }
  if (msg.type === 'assistant' && msg.message?.content) {
    for (const block of msg.message.content) {
      if (block.type === 'text' && block.text) {
        events.push(stamp({ sessionId, type: 'assistant_text', text: block.text }))
      } else if (block.type === 'thinking') {
        // Emit thinking events even when block.thinking is '' — Opus 4.7
        // with subscription auth (and any model in 'redacted thinking'
        // mode) writes only the signature to the JSONL, leaving the
        // plaintext blank. We still want the row to appear so 'Thought
        // for Ns' shows the wall-clock span between prev and current
        // message, even with no body text to expand.
        //
        // Span: thinking BEGAN when the previous message finished (user
        // input or tool_result) and ENDED when this message was committed.
        // Setting _t to prev-message and _endT to this-message lets
        // ChatLog's ThinkingGroup compute a non-zero "Thought for Ns".
        const ev = { sessionId, type: 'thinking', text: block.thinking || '' }
        if (typeof prevMessageT === 'number' && _t && prevMessageT < _t) {
          ev._t = prevMessageT
          ev._endT = _t
        } else if (_t) {
          ev._t = _t
        }
        events.push(ev)
      } else if (block.type === 'tool_use') {
        events.push(stamp({ sessionId, type: 'tool_use', tool: block.name, input: block.input, callId: block.id }))
      }
    }
    // The SDK only writes 'result' messages to its live stream — they're
    // never persisted to the JSONL — but every assistant message carries
    // the same usage payload (input_tokens, cache_*, iterations). Emit a
    // synthetic result so the browser's context meter has something to
    // read after a session is resumed/refreshed.
    if (msg.message.usage) {
      // Look up the cached contextWindow / maxOutputTokens for this model
      // (populated by live result events). Without it the browser falls
      // back to a hardcoded 200k window which is wrong for opus-4-7 1M.
      const modelUsage = msg.message.model
        ? modelWindows.asModelUsage(msg.message.model)
        : null
      events.push(stamp({
        sessionId,
        type: 'result',
        subtype: msg.message.stop_reason || null,
        usage: msg.message.usage,
        modelUsage,
        costUsd: null
      }))
    }
    return
  }
  if (msg.type === 'user' && Array.isArray(msg.message?.content)) {
    for (const block of msg.message.content) {
      if (block.type === 'tool_result') {
        const out = typeof block.content === 'string'
          ? block.content
          : Array.isArray(block.content) ? block.content.map(c => c.text || '').join('') : ''
        events.push(stamp({ sessionId, type: 'tool_result', callId: block.tool_use_id, content: out, isError: !!block.is_error }))
      } else if (block.type === 'text' && block.text) {
        events.push(stamp({ sessionId, type: 'user_input', text: block.text }))
      }
    }
    // SDK also stores plain string user prompts as message.content === string
    if (typeof msg.message.content === 'string' && msg.message.content) {
      events.push(stamp({ sessionId, type: 'user_input', text: msg.message.content }))
    }
    return
  }
  if (msg.type === 'user' && typeof msg.message?.content === 'string') {
    events.push(stamp({ sessionId, type: 'user_input', text: msg.message.content }))
    return
  }
  if (msg.type === 'result') {
    events.push(stamp({
      sessionId, type: 'result',
      subtype: msg.subtype || null,
      usage: msg.usage || null,
      modelUsage: msg.modelUsage || null,
      costUsd: msg.total_cost_usd ?? null
    }))
  }
}

module.exports = { listProjects, listSessionsInProject, listAll, ROOT, findTranscript, readSessionEvents }
