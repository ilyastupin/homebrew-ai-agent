// single-instance.js
// Ensure only one inpoint-claude agent runs per machine. On startup,
// check ~/.claude-terminal-proxy/agent.lock. If a previous agent's PID
// is still alive, send it SIGTERM and wait briefly for it to exit
// before installing our own PID. On exit we unlink the lockfile (only
// if it is still ours) so the next start doesn't poke a dead PID.
//
// Two rules learned the hard way (2026-10-30):
//   • Never take over from INSIDE the running agent. A Claude session
//     ran `inpoint-claude -v` to check the version; -v means verbose, so
//     it started a full agent, which SIGTERMed its own grandparent — the
//     agent hosting that very session. Everything went quiet and the
//     browser sat on "Thinking…". Now: if the lock holder is one of our
//     ancestors, refuse and exit.
//   • Never exit silently on a signal. This module used to install
//     SIGINT/SIGTERM/SIGHUP handlers that called process.exit(0) with no
//     output, and because they were registered first they beat the
//     agent's own shutdown(). Signals are now handled by supervisor.js,
//     which says what happened. Before SIGTERMing a predecessor we leave a
//     note (agent.takeover.json) so it can print who replaced it.
//
// Cross-platform notes:
//   • process.kill(pid, 0) is the standard "is this PID alive?" test —
//     supported by libuv on Windows too.
//   • SIGTERM on Windows is treated as SIGKILL by libuv (process dies
//     immediately). The worker notices its supervisor is gone and stops.
//   • The ancestor walk uses `ps`, so it runs on macOS/Linux only.

const fs = require('node:fs')
const path = require('node:path')
const os = require('node:os')
const { execFileSync } = require('node:child_process')

const LOCK_DIR = path.join(os.homedir(), '.claude-terminal-proxy')
const LOCK_FILE = path.join(LOCK_DIR, 'agent.lock')
const TAKEOVER_FILE = path.join(LOCK_DIR, 'agent.takeover.json')

function isAlive(pid) {
  try { process.kill(pid, 0); return true }
  catch (err) {
    // ESRCH = no such process. EPERM = process exists but we can't
    // signal it (e.g. running as different user) — counts as alive.
    return err && err.code === 'EPERM'
  }
}

function sleepSync(ms) {
  // Tiny synchronous wait — only used at startup before we hand control
  // to the event loop. Atomics.wait is the cross-platform way to block.
  const buf = new SharedArrayBuffer(4)
  Atomics.wait(new Int32Array(buf), 0, 0, ms)
}

function psField(pid, field) {
  try {
    return execFileSync('ps', ['-o', `${field}=`, '-p', String(pid)],
      { encoding: 'utf8', timeout: 2000, stdio: ['ignore', 'pipe', 'ignore'] }).trim()
  } catch { return '' }
}

/** Our ancestor chain, nearest first: [{ pid, command }]. Empty on Windows. */
function ancestors() {
  if (process.platform === 'win32') return []
  const out = []
  let pid = process.ppid
  for (let i = 0; i < 40 && pid > 1; i++) {
    out.push({ pid, command: psField(pid, 'command') })
    const next = parseInt(psField(pid, 'ppid'), 10)
    if (!Number.isFinite(next) || next === pid) break
    pid = next
  }
  return out
}

/** Who started us, in a few words, for the predecessor's log. */
function describeSelf(chain) {
  return {
    pid: process.pid,
    cwd: process.cwd(),
    argv: process.argv.slice(2).join(' '),
    parent: (chain[0]?.command || '').slice(0, 200)
  }
}

/** Read and consume the note a newer instance left before SIGTERMing us.
 *  Returns a human sentence, or null if no fresh note is addressed to us. */
function readTakeoverNote() {
  try {
    const note = JSON.parse(fs.readFileSync(TAKEOVER_FILE, 'utf8'))
    if (note.victimPid !== process.pid) return null
    if (Date.now() - (note.at || 0) > 30000) return null
    try { fs.unlinkSync(TAKEOVER_FILE) } catch {}
    const by = note.by || {}
    return `replaced by a newer inpoint-claude (pid ${by.pid}, started in ${by.cwd}` +
      (by.argv ? `, args "${by.argv}"` : '') + (by.parent ? `, from "${by.parent}"` : '') + ')'
  } catch { return null }
}

/**
 * Take the singleton lock. Kills any prior live agent first — unless that
 * agent is one of our ancestors, in which case we refuse and exit(1).
 * Call once at startup BEFORE we start listening on anything.
 */
function takeLock() {
  let priorPid = null
  try {
    const raw = fs.readFileSync(LOCK_FILE, 'utf8').trim()
    const n = parseInt(raw, 10)
    if (Number.isFinite(n) && n > 0 && n !== process.pid) priorPid = n
  } catch { /* no lockfile — fresh start */ }

  if (priorPid && isAlive(priorPid)) {
    const chain = ancestors()
    if (chain.some(a => a.pid === priorPid)) {
      console.error(
        `[single-instance] NOT starting: inpoint-claude is already running (pid ${priorPid}) ` +
        `and this command was launched from inside one of its own sessions. ` +
        `Taking over would kill the agent that runs this very session.\n` +
        `  Check the version with:  inpoint-claude --version\n` +
        `  Restart the agent from your own terminal, not from a chat.`)
      process.exit(1)
    }

    console.log(`[single-instance] another agent is running (pid ${priorPid}) — stopping it`)
    try {
      fs.mkdirSync(LOCK_DIR, { recursive: true })
      fs.writeFileSync(TAKEOVER_FILE, JSON.stringify({ victimPid: priorPid, at: Date.now(), by: describeSelf(chain) }))
    } catch { /* the note is diagnostics only */ }
    try { process.kill(priorPid, 'SIGTERM') } catch { /* race */ }
    // The old supervisor tells its worker to finish and flush its last
    // events to the browser, so allow a few seconds. Poll every 100 ms.
    const deadline = Date.now() + 6000
    while (Date.now() < deadline && isAlive(priorPid)) {
      sleepSync(100)
    }
    if (isAlive(priorPid)) {
      console.log(`[single-instance] prior agent still up — SIGKILL`)
      try { process.kill(priorPid, 'SIGKILL') } catch { /* gone */ }
      sleepSync(200)
    }
  }

  try { fs.mkdirSync(LOCK_DIR, { recursive: true }) } catch {}
  try { fs.writeFileSync(LOCK_FILE, String(process.pid)) }
  catch (err) {
    console.error(`[single-instance] could not write lockfile: ${err.message}`)
  }

  // Unlink on exit — but only if the lock is still ours, so a replaced
  // agent finishing up doesn't delete its successor's lock.
  process.on('exit', () => {
    try {
      if (fs.readFileSync(LOCK_FILE, 'utf8').trim() === String(process.pid)) fs.unlinkSync(LOCK_FILE)
    } catch {}
  })
}

module.exports = { takeLock, readTakeoverNote, LOCK_FILE }
