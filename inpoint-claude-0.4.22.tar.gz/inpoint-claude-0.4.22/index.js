// Claude Terminal Proxy — agent process.
// Connects to an etra-ai server and runs Claude Agent SDK sessions on demand.

// Prefix every stdout / stderr line with HH:MM:SS so the agent's terminal
// reads chronologically. Lines that already start with '#NNNN' (per-event
// numbered traces from uplink.js) skip the prefix — those format their
// own timestamp inline so the number stays at the very left for grouping.
;(() => {
  const _log = console.log
  const _err = console.error
  const ts = () => {
    const d = new Date()
    const p = n => String(n).padStart(2, '0')
    return `${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`
  }
  const wrap = (orig) => (...args) => {
    const first = args[0]
    if (typeof first === 'string' && /^#\d{4}\b/.test(first)) {
      orig(...args)
    } else if (typeof first === 'string') {
      orig(`${ts()} ${first}`, ...args.slice(1))
    } else {
      orig(ts(), ...args)
    }
  }
  console.log = wrap(_log)
  console.error = wrap(_err)
})()

// --version prints and exits. (-v is --verbose, not version: a Claude
// session that ran `inpoint-claude -v` to check the version started a
// second agent instead, which killed the first one — 2026-10-30.)
if (process.argv.slice(2).some(a => a === '--version' || a === '-V')) {
  process.stdout.write(`inpoint-claude ${require('./package.json').version}\n`)
  process.exit(0)
}

// Two roles in one file. Started by a person (or brew's wrapper), this
// process is the SUPERVISOR: it takes the single-instance lock and runs
// itself again as the WORKER (INPOINT_CLAUDE_WORKER=1), restarting it
// if it dies on its own. --help and --token answer and exit, no
// supervisor needed. See supervisor.js.
const QUICK_FLAGS = new Set(['--help', '--token'])
if (process.env.INPOINT_CLAUDE_WORKER !== '1' && !process.argv.slice(2).some(a => QUICK_FLAGS.has(a))) {
  require('./supervisor').run({ script: __filename, args: process.argv.slice(2) })
  return  // CommonJS module scope — ends this file's top-level code
}

const { loadConfig, saveConfig } = require('./config')
const { createUplink } = require('./uplink')
const { SessionManager } = require('./session-manager')
const sessionStore = require('./session-store')

function parseArgs(args) {
  // forceProxy defaults to TRUE — every claude call goes through
  // ai.inpoint.dev's /api/anthropic-proxy so the central BYOK key
  // resolver applies (centralised billing + access control). Pass
  // --local to opt out and use the agent's own OAuth / API key for
  // direct SDK calls.
  const opts = { server: null, apiKey: null, endpoint: null, name: null, showToken: false, verbose: false, forceProxy: true }
  for (let i = 0; i < args.length; i++) {
    switch (args[i]) {
      case '--server': opts.server = args[++i]; break
      case '--api-key': opts.apiKey = args[++i]; break
      case '--endpoint': opts.endpoint = args[++i]; break
      // --name overrides the displayed agent name (which by default
      // is os.hostname() on first start). Persisted to agent.json so
      // future starts keep the override unless --name is passed again.
      case '--name': opts.name = args[++i]; break
      case '--token': opts.showToken = true; break
      case '-v':
      case '--verbose': opts.verbose = true; break
      // --force-proxy is now the default; accept it as a no-op so any
      // existing scripts / docs that still pass it keep working.
      case '--force-proxy': opts.forceProxy = true; break
      // --local is the public opt-out flag. --no-force-proxy is the
      // legacy spelling, kept as an alias to avoid breaking scripts
      // and shell history.
      case '--local':
      case '--no-force-proxy': opts.forceProxy = false; break
      case '--help': printUsage(); process.exit(0)
    }
  }
  return opts
}

function loadDotEnv() {
  const fs = require('fs')
  const path = require('path')
  const envPath = path.join(process.cwd(), '.env')
  if (!fs.existsSync(envPath)) return
  try {
    for (const line of fs.readFileSync(envPath, 'utf-8').split('\n')) {
      const trimmed = line.trim()
      if (!trimmed || trimmed.startsWith('#')) continue
      const m = trimmed.match(/^(?:export\s+)?([^=]+)=(.*)$/)
      if (!m) continue
      const key = m[1].trim()
      let value = m[2].trim()
      if ((value.startsWith('"') && value.endsWith('"')) ||
          (value.startsWith("'") && value.endsWith("'"))) {
        value = value.slice(1, -1)
      }
      if (!process.env[key]) process.env[key] = value
    }
  } catch { /* ignore */ }
}

function printUsage() {
  console.log(`
Claude Terminal Proxy — Claude Agent SDK bridge

Usage:
  inpoint-claude [-v] [--local] [--name <name>] [--server <url>] [--token]

Defaults: connects to https://ai.inpoint.dev and routes every Claude
call through that server's /api/anthropic-proxy endpoint (centralised
BYOK key resolution + billing). Pass --local to use your own OAuth /
API key directly instead.

Options:
  -v, --verbose       Log every message received from the Claude Agent SDK
                      to stdout. Useful for debugging streaming, tool use,
                      and permission round-trips. Recommended.
  --local             Opt out of proxy mode: use the agent's own local
                      OAuth / API key for every Claude call, bypassing the
                      server's BYOK resolver. For local development.
  --name <name>       Display name for this agent in the web UI. Defaults
                      to the machine's hostname on first start. Saved in
                      config after use; pass again to rename.
  --server <url>      Server URL to connect to. Defaults to
                      https://ai.inpoint.dev. Saved in config after first
                      use, so this flag is only needed once (or to change).
  --token             Print this agent's share token and exit.
  --version, -V       Print the agent version and exit. (-v is --verbose
                      and starts the agent.)
  --api-key <key>     Optional ANTHROPIC_API_KEY fallback for --local mode.
                      If absent, the SDK uses your claude.ai OAuth login
                      from the OS keychain.
  --endpoint <url>    Override the Anthropic API base URL (sets
                      ANTHROPIC_BASE_URL). Use to route Claude calls
                      through a custom proxy / mirror / Bedrock-shim —
                      e.g. when api.anthropic.com is blocked.
                      Example: --endpoint https://ai.inpoint.dev/api/anthropic-proxy
  --force-proxy       Accepted for back-compat — proxy mode is the
                      default, so passing this is a no-op.
  --no-force-proxy    Legacy alias for --local.
  --help              Show this message

Agent config is stored in ~/.claude-terminal-proxy/agent.json
Past Claude sessions are read from ~/.claude/projects/
`)
}

const opts = parseArgs(process.argv.slice(2))
loadDotEnv()
const config = loadConfig()

if (opts.showToken) {
  console.log(config.shareToken)
  process.exit(0)
}

if (!config.serverUrl && !opts.server) {
  config.serverUrl = 'https://ai.inpoint.dev'
}

if (opts.server) { config.serverUrl = opts.server; saveConfig(config) }
if (opts.apiKey) { config.defaultApiKey = opts.apiKey; saveConfig(config) }
// --name overrides whatever loadConfig() defaulted to (os.hostname).
// Trim because shells happily pass " " through; reject empty so users
// can't accidentally blank their identity. Persisted, like --server.
if (opts.name) {
  const n = String(opts.name).trim()
  if (n) { config.name = n; saveConfig(config) }
}
// --endpoint persists in config so a restart keeps the override. Pass an
// empty string to clear: `inpoint-claude --endpoint ""`.
if (opts.endpoint !== null) {
  config.anthropicBaseUrl = opts.endpoint || null
  saveConfig(config)
}

// --force-proxy is a runtime-only flag (NOT persisted): tells applyAuth()
// in uplink to ignore local creds + server policy and always route every
// Claude call through the configured server's /api/anthropic-proxy.
config.forceProxy = !!opts.forceProxy

const serverUrl = config.serverUrl || null
const envApiKey = process.env.ANTHROPIC_API_KEY
const effectiveDefaultKey = config.defaultApiKey || envApiKey

// Banner. Auth + endpoint info is intentionally NOT printed here —
// the actual mode is decided post-heartbeat by applyAuth() in uplink
// (it depends on the server's allowOwnCreds policy + what credentials
// are present), and applyAuth prints `[auth] Using ...` once it
// resolves. Account identity (email / org / plan) prints `[account]`
// once the SDK reports it on the first session start. Printing
// configured-state lines here was misleading: e.g. having an
// --endpoint set + OAuth in keychain looks like "use proxy + use
// OAuth" but only ONE wins, and not in any obvious way.
console.log(`Claude Terminal Proxy`)
console.log(`  Name:        ${config.name}`)
console.log(`  Server:      ${serverUrl || '(not configured)'}`)
console.log(`  Mine token:  ${config.mineToken.slice(0, 15)}... (private — do not share)`)
console.log(`  Share token: ${config.shareToken}`)
console.log(`               ↑ paste into "Paste agent token…" at ${(serverUrl || 'https://ai.inpoint.dev').replace(/\/$/, '')}/claude`)
console.log()

if (!serverUrl) {
  console.error('Error: No server URL configured. Use --server <url>')
  process.exit(require('./supervisor').EXIT_NO_RESTART)
}

// The single-instance lock is held by the supervisor (supervisor.js),
// not by this worker — a worker restart must not look like a takeover.

// If a default API key is configured, expose it to the SDK via env.
if (config.defaultApiKey && !process.env.ANTHROPIC_API_KEY) {
  process.env.ANTHROPIC_API_KEY = config.defaultApiKey
}

// Two-phase wiring: SessionManager needs an emit callback, but the uplink
// needs SessionManager to dispatch commands. Build uplink with a forwarder
// closure that resolves to SessionManager once it exists.
let sessionManager = null
// Proxy so the uplink can call any SessionManager method (current and
// future) without having to keep this list in sync. Necessary because
// `sessionManager` is `let` and only assigned AFTER createUplink — the
// uplink needs a stable reference. Each method goes through `this`-
// preserved binding so the SessionManager instance's `this` is correct.
const sessionManagerRef = new Proxy({}, {
  get(_target, prop) {
    if (!sessionManager) return undefined
    const v = sessionManager[prop]
    if (typeof v === 'function') return v.bind(sessionManager)
    return v
  }
})

const uplink = createUplink(serverUrl, config, sessionManagerRef, sessionStore)
sessionManager = new SessionManager({
  emit: (event) => uplink.emit(event),
  log: (msg) => console.log(`[session] ${msg}`),
  config,
  verbose: opts.verbose
})

uplink.start()

// ---------- Stopping, always out loud ----------
// Every way out of this process prints why, tells each open chat in the
// browser (closeAll → error + session_closed), waits up to 3 s for those
// events to reach the server, then exits. The supervisor restarts us
// unless it asked us to stop.
let stopping = false
async function shutdown(why, code) {
  if (stopping) return
  stopping = true
  console.log('')
  console.log(`[exit] agent ${why}`)
  // Hard ceiling: whatever happens below, we are gone in 5 s.
  setTimeout(() => process.exit(code), 5000)
  try { uplink.stop() } catch {}
  try { sessionManager.closeAll(why) } catch (err) { console.error(`[exit] closeAll failed: ${err?.message || err}`) }
  const sent = await uplink.drain(3000)
  if (!sent) console.log('[exit] some events did not reach the server in time')
  process.exit(code)
}

// Ctrl+C reaches both us and the supervisor (same process group).
process.on('SIGINT', () => shutdown('stopped by Ctrl+C (SIGINT)', 130))
process.on('SIGTERM', () => shutdown('stopped by SIGTERM', 143))
process.on('SIGHUP', () => shutdown('stopped because its terminal was closed (SIGHUP)', 129))
// The supervisor sends the human reason (incl. who took over) first.
process.on('message', msg => {
  if (msg && msg.type === 'stop') shutdown(msg.reason || 'stopped by its supervisor', 0)
})
// Supervisor gone (killed with -9, crashed): nobody would restart us, and
// a new agent may already be starting — step aside.
process.on('disconnect', () => shutdown('stopped because its supervisor process is gone', 0))

process.on('uncaughtException', err => {
  console.error(`[crash] uncaught exception:\n${err?.stack || err}`)
  shutdown(`crashed (${err?.message || err}); restarting`, 1)
})
// A stray rejected promise is logged loudly but does not take every open
// chat down with it — Node's default would kill the process.
process.on('unhandledRejection', reason => {
  console.error(`[crash] unhandled promise rejection (agent keeps running):\n${reason?.stack || reason}`)
})
