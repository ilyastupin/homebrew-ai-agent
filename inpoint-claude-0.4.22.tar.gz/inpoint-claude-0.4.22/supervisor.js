// supervisor.js — keeps the agent alive.
//
// `inpoint-claude` starts this small parent process; it owns the
// single-instance lock and runs the real agent (index.js with
// INPOINT_CLAUDE_WORKER=1) as a child. If the child dies on its own —
// a crash, an out-of-memory kill, a stray signal — the supervisor says
// so and starts it again with a growing pause. It does NOT restart when
// a person stopped the agent:
//
//   Ctrl+C (SIGINT)   — "stopped by Ctrl+C (SIGINT)", exit 130
//   SIGTERM           — usually a newer inpoint-claude taking over; we
//                       print who it was (agent.takeover.json), exit 143
//   SIGHUP            — the terminal window was closed, exit 129
//
// In every case the reason is passed to the worker over IPC first, so it
// can tell each open chat in the browser why the agent went away before
// it exits, instead of leaving the chat on "Thinking…".

const { fork } = require('node:child_process')
const { takeLock, readTakeoverNote } = require('./single-instance')

const BACKOFF_S = [1, 2, 5, 10, 30, 60]
const STABLE_MS = 10 * 60 * 1000      // this long up → next crash starts the backoff over
const STOP_GRACE_MS = 5000            // worker gets this long to flush and exit
const EXIT_NO_RESTART = 78            // worker's way to say "restarting won't help"

const SIGNAL_EXIT = { SIGINT: 130, SIGTERM: 143, SIGHUP: 129 }

function run({ script, args }) {
  takeLock()

  let child = null
  let startedAt = 0
  let crashes = 0
  let stopping = null      // { reason, code } once a stop was requested
  let restartTimer = null

  function start() {
    restartTimer = null
    startedAt = Date.now()
    child = fork(script, args, {
      env: { ...process.env, INPOINT_CLAUDE_WORKER: '1' },
      stdio: ['inherit', 'inherit', 'inherit', 'ipc']
    })
    child.on('exit', onChildExit)
    child.on('error', err => console.error(`[supervisor] worker error: ${err.message}`))
  }

  function onChildExit(code, signal) {
    child = null
    if (stopping) {
      console.log(`[supervisor] agent ${stopping.reason}`)
      process.exit(stopping.code)
    }
    const how = signal ? `killed by ${signal}` : `exited with code ${code}`
    if (code === EXIT_NO_RESTART) {
      console.error(`[supervisor] agent ${how} and asked not to be restarted — giving up`)
      process.exit(1)
    }
    if (Date.now() - startedAt > STABLE_MS) crashes = 0
    const wait = BACKOFF_S[Math.min(crashes, BACKOFF_S.length - 1)]
    crashes++
    console.error(`[supervisor] agent ${how} unexpectedly after ${Math.round((Date.now() - startedAt) / 1000)}s — restarting in ${wait}s (restart #${crashes})`)
    restartTimer = setTimeout(start, wait * 1000)
  }

  function stop(reason, code) {
    if (stopping) return
    stopping = { reason, code }
    if (restartTimer) { clearTimeout(restartTimer); restartTimer = null }
    if (!child) {
      console.log(`[supervisor] agent ${reason}`)
      process.exit(code)
    }
    try { child.send({ type: 'stop', reason }) } catch { /* channel gone — the signal still works */ }
    const c = child
    setTimeout(() => {
      if (child === c) {
        console.error(`[supervisor] agent did not stop within ${STOP_GRACE_MS / 1000}s — killing it`)
        try { c.kill('SIGKILL') } catch {}
      }
    }, STOP_GRACE_MS)
  }

  process.on('SIGINT', () => stop('stopped by Ctrl+C (SIGINT)', SIGNAL_EXIT.SIGINT))
  process.on('SIGHUP', () => stop('stopped because its terminal was closed (SIGHUP)', SIGNAL_EXIT.SIGHUP))
  process.on('SIGTERM', () => {
    const note = readTakeoverNote()
    stop(note ? `stopped: ${note}` : 'stopped by SIGTERM (kill, logout or shutdown)', SIGNAL_EXIT.SIGTERM)
  })

  start()
}

module.exports = { run, EXIT_NO_RESTART }
