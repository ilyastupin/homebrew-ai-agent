// Claude Terminal Proxy — agent process.
// Connects to an etra-ai server and runs Claude Agent SDK sessions on demand.

const { loadConfig, saveConfig } = require('./config')
const { createUplink } = require('./uplink')
const { SessionManager } = require('./session-manager')
const sessionStore = require('./session-store')

function parseArgs(args) {
  const opts = { server: null, apiKey: null }
  for (let i = 0; i < args.length; i++) {
    switch (args[i]) {
      case '--server': opts.server = args[++i]; break
      case '--api-key': opts.apiKey = args[++i]; break
      case '--help': printUsage(); process.exit(0)
    }
  }
  return opts
}

function loadDotEnv() {
  const fs = require('fs')
  const path = require('path')
  const envPath = path.join(process.cwd(), '.env')
  if (!fs.existsSync(envPath)) return
  try {
    for (const line of fs.readFileSync(envPath, 'utf-8').split('\n')) {
      const trimmed = line.trim()
      if (!trimmed || trimmed.startsWith('#')) continue
      const m = trimmed.match(/^(?:export\s+)?([^=]+)=(.*)$/)
      if (!m) continue
      const key = m[1].trim()
      let value = m[2].trim()
      if ((value.startsWith('"') && value.endsWith('"')) ||
          (value.startsWith("'") && value.endsWith("'"))) {
        value = value.slice(1, -1)
      }
      if (!process.env[key]) process.env[key] = value
    }
  } catch { /* ignore */ }
}

function printUsage() {
  console.log(`
Claude Terminal Proxy — Claude Agent SDK bridge

Usage:
  node index.js --server <url>

Options:
  --server <url>      Server URL to connect to (e.g., https://ai.inpoint.dev)
                      Saved in config after first use.
  --api-key <key>     Optional ANTHROPIC_API_KEY fallback. If absent, the SDK
                      uses your claude.ai OAuth login from the OS keychain.
  --help              Show this message

Agent config is stored in ~/.claude-terminal-proxy/agent.json
Past Claude sessions are read from ~/.claude/projects/
`)
}

const opts = parseArgs(process.argv.slice(2))
loadDotEnv()
const config = loadConfig()

// Show help only when there's nothing to run — no args AND no saved server URL.
if (process.argv.length <= 2 && !config.serverUrl) {
  printUsage()
  process.exit(0)
}

if (opts.server) { config.serverUrl = opts.server; saveConfig(config) }
if (opts.apiKey) { config.defaultApiKey = opts.apiKey; saveConfig(config) }

const serverUrl = config.serverUrl || null
const envApiKey = process.env.ANTHROPIC_API_KEY
const effectiveDefaultKey = config.defaultApiKey || envApiKey

console.log(`Claude Terminal Proxy`)
console.log(`  Name:        ${config.name}`)
console.log(`  Server:      ${serverUrl || '(not configured)'}`)
console.log(`  Mine token:  ${config.mineToken.slice(0, 15)}...`)
console.log(`  Share token: ${config.shareToken.slice(0, 16)}...`)
console.log(`  Auth:        ${effectiveDefaultKey ? 'API key (' + effectiveDefaultKey.slice(0, 12) + '...)' : 'OAuth keychain (claude /login)'}`)
console.log()

if (!serverUrl) {
  console.error('Error: No server URL configured. Use --server <url>')
  process.exit(1)
}

// If a default API key is configured, expose it to the SDK via env.
if (config.defaultApiKey && !process.env.ANTHROPIC_API_KEY) {
  process.env.ANTHROPIC_API_KEY = config.defaultApiKey
}

// Two-phase wiring: SessionManager needs an emit callback, but the uplink
// needs SessionManager to dispatch commands. Build uplink with a forwarder
// closure that resolves to SessionManager once it exists.
let sessionManager = null
const sessionManagerRef = {
  create: (...a) => sessionManager.create(...a),
  delete: (...a) => sessionManager.delete(...a),
  list: (...a) => sessionManager.list(...a),
  get: (...a) => sessionManager.get(...a)
}

const uplink = createUplink(serverUrl, config, sessionManagerRef, sessionStore)
sessionManager = new SessionManager({
  emit: (event) => uplink.emit(event),
  log: (msg) => console.log(`[session] ${msg}`),
  config
})

uplink.start()

function shutdown() {
  console.log('\nShutting down...')
  uplink.stop()
  sessionManager.closeAll()
  process.exit(0)
}
process.on('SIGINT', shutdown)
process.on('SIGTERM', shutdown)
