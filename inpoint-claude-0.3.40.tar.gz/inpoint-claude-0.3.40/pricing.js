// pricing.js — public Anthropic per-model pricing for cost estimation.
//
// Anthropic publishes rates at docs.anthropic.com/en/docs/about-claude/pricing.
// All values below are USD per 1,000,000 tokens.
//
// Rate columns:
//   input        — uncached input tokens
//   output       — output tokens
//   cache5m      — 5-minute ephemeral cache write (1.25× input)
//   cache1h      — 1-hour ephemeral cache write (2.0× input)
//   cacheRead    — cache hit on either tier (0.1× input)
//
// The cost compute reads `usage.cache_creation.ephemeral_5m_input_tokens`
// and `ephemeral_1h_input_tokens` separately so a turn that wrote half
// to each tier is billed correctly. The flat `cache_creation_input_tokens`
// field is used as a fallback (and assumed 5m) when the per-tier
// breakdown is absent (older agent / older SDK).
//
// The model lookup is by id prefix so a future "claude-opus-4-8" rides
// along on the opus rates without a code change. The Sonnet 1M-context
// premium tier is detected via the contextWindow opt — set it to >200k
// when calling and we'll switch to the higher-priced rate row.

const RATES_OPUS = { input: 15, output: 75, cache5m: 18.75, cache1h: 30, cacheRead: 1.5 }
const RATES_SONNET = { input: 3, output: 15, cache5m: 3.75, cache1h: 6, cacheRead: 0.3 }
const RATES_SONNET_1M = { input: 6, output: 22.5, cache5m: 7.5, cache1h: 12, cacheRead: 0.6 }
const RATES_HAIKU = { input: 1, output: 5, cache5m: 1.25, cache1h: 2, cacheRead: 0.1 }

function ratesFor(model, opts = {}) {
  if (typeof model !== 'string') return null
  // Sonnet has a premium tier when context window > 200k. The SDK's
  // result.modelUsage carries that, surfaced via opts.contextWindow.
  if (model.startsWith('claude-sonnet-4-')) {
    return opts.contextWindow > 200_000 ? RATES_SONNET_1M : RATES_SONNET
  }
  if (model.startsWith('claude-opus-4-')) return RATES_OPUS
  if (model.startsWith('claude-haiku-4-')) return RATES_HAIKU
  return null
}

// Compute USD cost for a single SDK usage payload (the `message.usage`
// object found on every assistant line in a JSONL transcript). Returns
// null if the model is unrecognised AND the usage represents real
// spend; the UI renders "—" in that case. Returns 0 for SDK-synthetic
// placeholders (model='<synthetic>', all-zero usage — emitted for
// "No response requested" fillers etc.) so they don't poison the
// session's cumulative cost when the model isn't in the rate table.
function costForUsage(model, usage, opts = {}) {
  if (!usage) return null
  const tokenSum =
    (Number(usage.input_tokens) || 0) +
    (Number(usage.output_tokens) || 0) +
    (Number(usage.cache_creation_input_tokens) || 0) +
    (Number(usage.cache_read_input_tokens) || 0) +
    (Number(usage.cache_creation?.ephemeral_5m_input_tokens) || 0) +
    (Number(usage.cache_creation?.ephemeral_1h_input_tokens) || 0)
  if (tokenSum === 0) return 0
  const rates = ratesFor(model, opts)
  if (!rates) return null
  const input = Number(usage.input_tokens) || 0
  const output = Number(usage.output_tokens) || 0
  const cacheRead = Number(usage.cache_read_input_tokens) || 0
  // Per-tier breakdown when present; flat fallback otherwise.
  const cc = usage.cache_creation || {}
  const cache5m = Number(cc.ephemeral_5m_input_tokens) || 0
  const cache1h = Number(cc.ephemeral_1h_input_tokens) || 0
  const cacheCreateFlat = Number(usage.cache_creation_input_tokens) || 0
  const splitTotal = cache5m + cache1h
  const useFlat = splitTotal === 0 && cacheCreateFlat > 0
  const c5 = useFlat ? cacheCreateFlat : cache5m
  const c1 = useFlat ? 0 : cache1h
  return (
    (input    / 1_000_000) * rates.input +
    (output   / 1_000_000) * rates.output +
    (c5       / 1_000_000) * rates.cache5m +
    (c1       / 1_000_000) * rates.cache1h +
    (cacheRead / 1_000_000) * rates.cacheRead
  )
}

// Aggregate token + cost totals across an array of `{model, usage}`
// records (one per *unique* assistant message — caller should dedupe
// by message.id first, see session-store.js for why). Returns shape:
//   {
//     inputTokens, outputTokens, cacheCreate5m, cacheCreate1h, cacheRead,
//     costUsd | null,         // null only if EVERY entry had unknown model
//     hasUnknownModel: bool   // true if at least one entry was unrecognised
//   }
function aggregateTotals(records) {
  const totals = {
    inputTokens: 0, outputTokens: 0,
    cacheCreate5m: 0, cacheCreate1h: 0, cacheRead: 0,
    costUsd: 0, hasUnknownModel: false, hasKnownModel: false
  }
  for (const r of records) {
    const u = r?.usage
    if (!u) continue
    totals.inputTokens += Number(u.input_tokens) || 0
    totals.outputTokens += Number(u.output_tokens) || 0
    totals.cacheRead += Number(u.cache_read_input_tokens) || 0
    const cc = u.cache_creation || {}
    totals.cacheCreate5m += Number(cc.ephemeral_5m_input_tokens) || 0
    totals.cacheCreate1h += Number(cc.ephemeral_1h_input_tokens) || 0
    const c = costForUsage(r.model, u, r.opts || {})
    if (c == null) {
      totals.hasUnknownModel = true
    } else {
      totals.costUsd += c
      totals.hasKnownModel = true
    }
  }
  if (!totals.hasKnownModel) totals.costUsd = null
  return totals
}

module.exports = { costForUsage, ratesFor, aggregateTotals }
